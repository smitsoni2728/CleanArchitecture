﻿using System.Reflection;
using Audit.Core;
using PostSharp.Aspects;

namespace Api.Programs
{
    [Serializable]
    public class Utility : OnMethodBoundaryAspect
    {
        private static Object locker = new Object();
        public static string ComAssemblyPath = "";
        public enum LogType
        {
            Get = 0,
            Post = 1,
            Put = 2,
            Delete = 3,
            Time = 4
        }

        public enum FileExtentionType
        {
            xml,
            txt,
            json,
            html
        }

        public static void CreateFileLogs(
           string strReqRes,
           string strFileName,
           bool IsLogNeeded,
           LogType lgType,
           FileExtentionType fileType
       )
        {
            string fileName = "";
            string filePath = "";
            ComAssemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
            try
            {
                if (IsLogNeeded)
                {
                    filePath =
                        ComAssemblyPath
                            .Replace("file:\\", "")
                            .Replace("bin\\", "")
                            .Replace("Debug\\", "")
                            .Replace("net6.0", "")
                        + "Logs\\"
                        + DateTime.Now.ToString("dd-MMM-yyyy").Replace("-", "_")
                        + ""
                        + "\\";

                    if (!string.IsNullOrEmpty(strReqRes))
                    {
                        #region File Based logs

                        if (!string.IsNullOrEmpty(strReqRes))
                            filePath += "\\" + lgType.ToString() + "\\" + strReqRes;

                        if (!Directory.Exists(filePath))
                        {
                            Directory.CreateDirectory(filePath);
                        }

                        fileName =
                            filePath
                            + "\\"
                            + strFileName
                            + "_"
                            + DateTime.Now.ToString("ddMMyyyyHHmmssfff")
                            + "."
                            + fileType.ToString();

                        lock (locker)
                        {
                            using (
                                System.IO.StreamWriter file = new System.IO.StreamWriter(fileName)
                            )
                            {
                                file.WriteLine(strReqRes);
                                file.Flush();
                                file.Close();
                            }
                        }

                        #endregion
                    }
                    else
                    {
                        #region File Based logs

                        if (
                            !string.IsNullOrEmpty(strReqRes)
                            && lgType != LogType.Time
                        )
                            filePath +=
                                "\\" + lgType.ToString() + "\\" + strReqRes;
                        else
                            filePath += "\\" + lgType.ToString();

                        if (!Directory.Exists(filePath))
                        {
                            Directory.CreateDirectory(filePath);
                        }

                        if (lgType == LogType.Time)
                            fileName =
                                filePath
                                + "\\"
                                + strFileName
                                + "_"
                                + DateTime.Now.ToString("ddMMyyyy")
                                + "."
                                + fileType.ToString();
                        else
                            fileName =
                                filePath
                                + "\\"
                                + strFileName
                                + "_"
                                + DateTime.Now.ToString("ddMMyyyyHHmmssfff")
                                + "."
                                + fileType.ToString();

                        lock (locker)
                        {
                            using (System.IO.StreamWriter file = File.AppendText(fileName))
                            {
                                file.WriteLine(strReqRes);
                                file.Flush();
                                file.Close();
                            }
                        }

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                string err = ex.ToString();
                throw new Exception(err);
            }
        }

        public static void CreateLogFile()
        {
            try
            {
                string filePath = "";
                string funcName = "";
                var scope = AuditScope.Create(new AuditScopeOptions(){
                    EventType = "new",
                    TargetGetter = () => funcName,
                    ExtraFields = new {}
                });
            }
            catch (System.Exception)
            {
                
                throw;
            }
        }
    }
}
