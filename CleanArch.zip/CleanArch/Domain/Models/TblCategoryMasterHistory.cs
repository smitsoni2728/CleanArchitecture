﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCategoryMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CategoryId { get; set; }

    public string OldcategoryCode { get; set; } = null!;

    public string OldcategoryName { get; set; } = null!;

    public int OldcategoryTypeId { get; set; }

    public bool OldisActive { get; set; }

    public string NewcategoryCode { get; set; } = null!;

    public string NewcategoryName { get; set; } = null!;

    public int NewcategoryTypeId { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
