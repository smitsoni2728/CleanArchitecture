﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariantProductAttributeMapping
{
    public int ProductVariantAttributeId { get; set; }

    public int ProductVariantId { get; set; }

    public int ProductAttributeId { get; set; }

    public string TextPrompt { get; set; } = null!;

    public bool IsRequired { get; set; }

    public int AttributeControlTypeId { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopProductVariantAttributeValue> NopProductVariantAttributeValues { get; set; } = new List<NopProductVariantAttributeValue>();

    public virtual NopProductAttribute ProductAttribute { get; set; } = null!;

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
