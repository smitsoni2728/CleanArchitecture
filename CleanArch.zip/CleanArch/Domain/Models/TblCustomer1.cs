﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCustomer1
{
    public int CustomerId { get; set; }

    public string Name { get; set; } = null!;

    public byte Age { get; set; }

    public DateTime Dob { get; set; }

    public string CustAddress { get; set; } = null!;

    public int PhoneNo { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
