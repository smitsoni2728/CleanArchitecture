﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommissionSaleCountryDetail
{
    public int CommSaleCountryDetId { get; set; }

    public string AllowedCountryId { get; set; } = null!;

    public string RestricatedCountryId { get; set; } = null!;

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public int CommCriteriaId { get; set; }
}
