﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCommissionOrder
{
    public int CommOrderId { get; set; }

    public int CommGenerationId { get; set; }

    public int OrderId { get; set; }

    public int FromDistId { get; set; }

    public int ToDistId { get; set; }

    public int ProductId { get; set; }

    public int Qty { get; set; }

    public decimal Amount { get; set; }

    public short CreditDebit { get; set; }

    public decimal CommQtyRate { get; set; }

    public decimal CommPerRate { get; set; }

    public decimal CommAmountRate { get; set; }

    public decimal NetCommAmount { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public decimal Tdsamt { get; set; }

    public decimal Scamt { get; set; }

    public decimal EducessAmt { get; set; }
}
