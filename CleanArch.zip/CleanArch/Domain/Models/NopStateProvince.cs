﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopStateProvince
{
    public int StateProvinceId { get; set; }

    public int CountryId { get; set; }

    public string Name { get; set; } = null!;

    public string Abbreviation { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public virtual NopCountry Country { get; set; } = null!;
}
