﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ProductPurchase
{
    public int? ProductId { get; set; }

    public DateTime? PurchaseDate { get; set; }

    public int? Quantity { get; set; }
}
