﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBankMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int BankId { get; set; }

    public string OldbankCode { get; set; } = null!;

    public string OldbankName { get; set; } = null!;

    public string OldbankWebsiteUrl { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewbankCode { get; set; } = null!;

    public string NewbankName { get; set; } = null!;

    public string NewbankWebsiteUrl { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
