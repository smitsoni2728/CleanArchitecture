﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCustomerAttribute
{
    public int CustomerAttributeId { get; set; }

    public int CustomerId { get; set; }

    public string Key { get; set; } = null!;

    public string Value { get; set; } = null!;

    public virtual NopCustomer Customer { get; set; } = null!;
}
