﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmpH
{
    public int EmpId { get; set; }

    public string EmpCode { get; set; } = null!;

    public string EmpName { get; set; } = null!;

    public string Address { get; set; } = null!;

    public DateTime BirthDate { get; set; }

    public DateTime JoiningDate { get; set; }

    public decimal Salary { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
