﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Patientdetail
{
    public string? Snake { get; set; }

    public string? Tortoise { get; set; }

    public string? Leech { get; set; }

    public string? Frog { get; set; }

    public string? Peacock { get; set; }

    public string? Thithar { get; set; }

    public string? Elephant { get; set; }

    public string? Swan { get; set; }

    public string? Hen { get; set; }

    public string? Eyes { get; set; }

    public string? Nails { get; set; }

    public string? Tongue { get; set; }

    public string? Urine { get; set; }

    public string? Motion { get; set; }

    public string? Speech { get; set; }

    public string? Colour { get; set; }

    public string? Temp { get; set; }

    public string? Dhooh { get; set; }

    public string? Diseasesymptoms { get; set; }

    public string? Remadies { get; set; }

    public string? Possiblities { get; set; }

    public string? V1 { get; set; }

    public string? V2 { get; set; }

    public string? V3 { get; set; }

    public string? V4 { get; set; }

    public string? V5 { get; set; }

    public string? V6 { get; set; }

    public string? V7 { get; set; }

    public string? V8 { get; set; }

    public string? V9 { get; set; }

    public string? P1 { get; set; }

    public string? P2 { get; set; }

    public string? P3 { get; set; }

    public string? P4 { get; set; }

    public string? P5 { get; set; }

    public string? P6 { get; set; }

    public string? P7 { get; set; }

    public string? P8 { get; set; }

    public string? P9 { get; set; }

    public string? K1 { get; set; }

    public string? K2 { get; set; }

    public string? K3 { get; set; }

    public string? K4 { get; set; }

    public string? K5 { get; set; }

    public string? K6 { get; set; }

    public string? K7 { get; set; }

    public string? K8 { get; set; }

    public string? K9 { get; set; }

    public string? Opdno { get; set; }

    public virtual Patientmaster? OpdnoNavigation { get; set; }
}
