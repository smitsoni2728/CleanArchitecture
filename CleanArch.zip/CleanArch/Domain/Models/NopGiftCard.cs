﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopGiftCard
{
    public int GiftCardId { get; set; }

    public int PurchasedOrderProductVariantId { get; set; }

    public decimal Amount { get; set; }

    public bool IsGiftCardActivated { get; set; }

    public string GiftCardCouponCode { get; set; } = null!;

    public string RecipientName { get; set; } = null!;

    public string RecipientEmail { get; set; } = null!;

    public string SenderName { get; set; } = null!;

    public string SenderEmail { get; set; } = null!;

    public string Message { get; set; } = null!;

    public bool IsRecipientNotified { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual ICollection<NopGiftCardUsageHistory> NopGiftCardUsageHistories { get; set; } = new List<NopGiftCardUsageHistory>();

    public virtual NopOrderProductVariant PurchasedOrderProductVariant { get; set; } = null!;
}
