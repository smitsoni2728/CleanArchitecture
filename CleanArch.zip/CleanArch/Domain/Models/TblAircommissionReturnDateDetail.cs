﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommissionReturnDateDetail
{
    public int CommReturnDateDetId { get; set; }

    public DateTime FromReturnDate { get; set; }

    public DateTime ToReturnDate { get; set; }

    public byte OrderNo { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public int CommCriteriaId { get; set; }
}
