﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Newdeptmast
{
    public int DeptId { get; set; }

    public string DeptName { get; set; } = null!;
}
