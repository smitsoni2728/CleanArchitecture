﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopForumsPost
{
    public int PostId { get; set; }

    public int TopicId { get; set; }

    public int UserId { get; set; }

    public string Text { get; set; } = null!;

    public string Ipaddress { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopForumsTopic Topic { get; set; } = null!;
}
