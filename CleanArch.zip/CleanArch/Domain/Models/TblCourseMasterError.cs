﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCourseMasterError
{
    public int ErrorNo { get; set; }

    public string ErrorDesc { get; set; } = null!;

    public string Spname { get; set; } = null!;

    public string UserErrorDesc { get; set; } = null!;

    public bool IsDisplayErrorDesc { get; set; }
}
