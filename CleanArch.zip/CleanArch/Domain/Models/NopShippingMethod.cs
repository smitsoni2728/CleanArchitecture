﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopShippingMethod
{
    public int ShippingMethodId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopShippingByTotal> NopShippingByTotals { get; set; } = new List<NopShippingByTotal>();

    public virtual ICollection<NopShippingByWeightAndCountry> NopShippingByWeightAndCountries { get; set; } = new List<NopShippingByWeightAndCountry>();

    public virtual ICollection<NopShippingByWeight> NopShippingByWeights { get; set; } = new List<NopShippingByWeight>();

    public virtual ICollection<NopCountry> Countries { get; set; } = new List<NopCountry>();
}
