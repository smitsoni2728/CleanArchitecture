﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaPoiDatum
{
    public string? PoiId { get; set; }

    public string? PoiSeoId { get; set; }

    public string? PoiName { get; set; }

    public string? Latitude { get; set; }

    public string? Longitude { get; set; }

    public string? CityId { get; set; }

    public string? CityName { get; set; }

    public string? SeoCityName { get; set; }
}
