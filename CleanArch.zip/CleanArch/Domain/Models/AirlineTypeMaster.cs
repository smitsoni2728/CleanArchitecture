﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AirlineTypeMaster
{
    public int AirlineTypeId { get; set; }

    public int AirlineTypeCode { get; set; }

    public string AirlineTypeName { get; set; } = null!;

    public bool IsActive { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
