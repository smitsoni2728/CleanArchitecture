﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopManufacturerLocalized
{
    public int ManufacturerLocalizedId { get; set; }

    public int ManufacturerId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public string MetaTitle { get; set; } = null!;

    public string Sename { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopManufacturer Manufacturer { get; set; } = null!;
}
