﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ProductWcf
{
    public int ProductId { get; set; }

    public string ProductNumber { get; set; } = null!;

    public string ProductName { get; set; } = null!;

    public string Color { get; set; } = null!;

    public decimal Weight { get; set; }

    public decimal Price { get; set; }

    public virtual ICollection<ProductInventoryWcf> ProductInventoryWcfs { get; set; } = new List<ProductInventoryWcf>();
}
