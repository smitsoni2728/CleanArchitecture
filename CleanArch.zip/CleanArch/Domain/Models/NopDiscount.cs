﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopDiscount
{
    public int DiscountId { get; set; }

    public int DiscountTypeId { get; set; }

    public int DiscountRequirementId { get; set; }

    public decimal RequirementSpentAmount { get; set; }

    public int RequirementBillingCountryIs { get; set; }

    public int RequirementShippingCountryIs { get; set; }

    public int DiscountLimitationId { get; set; }

    public int LimitationTimes { get; set; }

    public string Name { get; set; } = null!;

    public bool UsePercentage { get; set; }

    public decimal DiscountPercentage { get; set; }

    public decimal DiscountAmount { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime EndDate { get; set; }

    public bool RequiresCouponCode { get; set; }

    public string CouponCode { get; set; } = null!;

    public bool Deleted { get; set; }

    public virtual ICollection<NopDiscountUsageHistory> NopDiscountUsageHistories { get; set; } = new List<NopDiscountUsageHistory>();

    public virtual ICollection<NopCategory> Categories { get; set; } = new List<NopCategory>();

    public virtual ICollection<NopCustomerRole> CustomerRoles { get; set; } = new List<NopCustomerRole>();

    public virtual ICollection<NopProductVariant> ProductVariants { get; set; } = new List<NopProductVariant>();

    public virtual ICollection<NopProductVariant> ProductVariantsNavigation { get; set; } = new List<NopProductVariant>();
}
