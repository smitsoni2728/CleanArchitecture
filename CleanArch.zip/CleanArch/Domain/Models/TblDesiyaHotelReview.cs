﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaHotelReview
{
    public string? VendorId { get; set; }

    public string? AvgGuestRating { get; set; }

    public string? OverallRating { get; set; }

    public string? Comments { get; set; }

    public string? RoomQuality { get; set; }

    public string? ServiceQuality { get; set; }

    public string? DiningQuality { get; set; }

    public string? Cleanliness { get; set; }

    public string? PostDate { get; set; }

    public string? ConsumerCity { get; set; }

    public string? ConsumerCountry { get; set; }

    public string? CustomerName { get; set; }
}
