﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorMasterRto
{
    public int DistributorId { get; set; }

    public string DistributorCode { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string MiddleName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public string MaritalStatus { get; set; } = null!;

    public DateTime BirthDate { get; set; }

    public string Occupation { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string FirmName { get; set; } = null!;

    public string ShippingAddressPref { get; set; } = null!;

    public string ResidAddressLine1 { get; set; } = null!;

    public string ResidAddressLine2 { get; set; } = null!;

    public string ResidAddressLine3 { get; set; } = null!;

    public string ResidCity { get; set; } = null!;

    public string ResidState { get; set; } = null!;

    public string ResidCountry { get; set; } = null!;

    public string ResidPinCode { get; set; } = null!;

    public string ResidPhoneNo { get; set; } = null!;

    public string Designation { get; set; } = null!;

    public string OfficeAddressLine1 { get; set; } = null!;

    public string OfficeAddressLine2 { get; set; } = null!;

    public string OfficeAddressLine3 { get; set; } = null!;

    public string OfficeCity { get; set; } = null!;

    public string OfficeState { get; set; } = null!;

    public string OfficeCountry { get; set; } = null!;

    public string OfficePinCode { get; set; } = null!;

    public string OfficePhoneNo { get; set; } = null!;

    public string OfficePhoneExt { get; set; } = null!;

    public string OfficeFax { get; set; } = null!;

    public string OperatorCode { get; set; } = null!;

    public string MobileNo { get; set; } = null!;

    public string Panno { get; set; } = null!;

    public bool IsPnremailAlerts { get; set; }

    public bool IsPnrsmsalerts { get; set; }

    public string UserName { get; set; } = null!;

    public string Pwd { get; set; } = null!;

    public byte ForgotPswdQueId { get; set; }

    public string ForgotPswdAns { get; set; } = null!;

    public bool IsActive { get; set; }

    public DateTime JoiningDate { get; set; }

    public DateTime ActivationDate { get; set; }

    public decimal DistributorShipAmt { get; set; }

    public bool IsTrial { get; set; }

    public DateTime TrialStartDate { get; set; }

    public DateTime TrialActivationdate { get; set; }

    public int UserId { get; set; }

    public DateTime CreatedDateTime { get; set; }

    public bool IsEmailSmssent { get; set; }

    public string CurrentSessionId { get; set; } = null!;

    public bool IsCustomer { get; set; }

    public DateTime LastUpdated { get; set; }

    public bool IsValidateInterface { get; set; }

    public int InterfaceId { get; set; }

    public bool IsForm60 { get; set; }

    public bool IsEtokenReceived { get; set; }

    public string IrctcsubUserId { get; set; } = null!;

    public string IrctcsubPassword { get; set; } = null!;

    public string IrctcsubTranUserId { get; set; } = null!;

    public string IrctcsubTranPassword { get; set; } = null!;

    public bool IsUseSubUser { get; set; }
}
