﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Product1
{
    public int ProductId { get; set; }

    public string? ProductName { get; set; }

    public int? ProductPrice { get; set; }

    public virtual ICollection<ProductSale> ProductSales { get; set; } = new List<ProductSale>();
}
