﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDtl
{
    public int IntCompId { get; set; }

    public int? Empno { get; set; }

    public string? Loc { get; set; }

    public Guid MsreplTranVersion { get; set; }

    public Guid Rowguid { get; set; }
}
