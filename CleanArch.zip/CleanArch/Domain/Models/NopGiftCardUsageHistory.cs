﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopGiftCardUsageHistory
{
    public int GiftCardUsageHistoryId { get; set; }

    public int GiftCardId { get; set; }

    public int CustomerId { get; set; }

    public int OrderId { get; set; }

    public decimal UsedValue { get; set; }

    public decimal UsedValueInCustomerCurrency { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;

    public virtual NopGiftCard GiftCard { get; set; } = null!;
}
