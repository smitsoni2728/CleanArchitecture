﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCoupon
{
    public int CouponId { get; set; }

    public string? CouponType { get; set; }

    public byte? CommandId { get; set; }

    public int? EventId { get; set; }

    public string? CouponCode { get; set; }

    public int? CouponPrice { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public int? CouponDiscount { get; set; }

    public bool? Isactive { get; set; }
}
