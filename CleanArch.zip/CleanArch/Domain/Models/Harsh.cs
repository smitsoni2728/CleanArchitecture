﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Harsh
{
    public int Empid { get; set; }

    public string? EmpName { get; set; }

    public string? EmpPosition { get; set; }

    public string? Emplocation { get; set; }
}
