﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopWarehouse
{
    public int WarehouseId { get; set; }

    public string Name { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string FaxNumber { get; set; } = null!;

    public string Address1 { get; set; } = null!;

    public string Address2 { get; set; } = null!;

    public string City { get; set; } = null!;

    public string StateProvince { get; set; } = null!;

    public string ZipPostalCode { get; set; } = null!;

    public int CountryId { get; set; }

    public bool Deleted { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }
}
