﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class DscCategory
{
    public int CategoryId { get; set; }

    public int? ParentId { get; set; }

    public string Name { get; set; } = null!;

    public int? ImageId { get; set; }

    public string? Description { get; set; }

    public int SortOrder { get; set; }

    public int ShowLevels { get; set; }

    public bool? ShowUsefulLinks { get; set; }

    public virtual ICollection<DscCategoryManufacturerCount> DscCategoryManufacturerCounts { get; set; } = new List<DscCategoryManufacturerCount>();

    public virtual ICollection<DscCategory> InverseParent { get; set; } = new List<DscCategory>();

    public virtual DscCategory? Parent { get; set; }
}
