﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDberrorLog
{
    public int LogId { get; set; }

    public int ErrorNo { get; set; }

    public byte Severity { get; set; }

    public int State { get; set; }

    public string Spname { get; set; } = null!;

    public int ErrorLine { get; set; }

    public string ErrorMsg { get; set; } = null!;

    public string ParamValue { get; set; } = null!;
}
