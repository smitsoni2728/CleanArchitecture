﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCheckoutAttribute
{
    public int CheckoutAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public string TextPrompt { get; set; } = null!;

    public bool IsRequired { get; set; }

    public bool ShippableProductRequired { get; set; }

    public bool IsTaxExempt { get; set; }

    public int TaxCategoryId { get; set; }

    public int AttributeControlTypeId { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopCheckoutAttributeLocalized> NopCheckoutAttributeLocalizeds { get; set; } = new List<NopCheckoutAttributeLocalized>();

    public virtual ICollection<NopCheckoutAttributeValue> NopCheckoutAttributeValues { get; set; } = new List<NopCheckoutAttributeValue>();
}
