﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class T101
{
    public int? A { get; set; }

    public int? B { get; set; }

    public int? C { get; set; }
}
