﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmpLeaveApproveDet
{
    public decimal? EladLeaveid { get; set; }

    public decimal? EladApproveid { get; set; }
}
