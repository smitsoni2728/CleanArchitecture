﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopForumsSubscription
{
    public int SubscriptionId { get; set; }

    public Guid SubscriptionGuid { get; set; }

    public int UserId { get; set; }

    public int ForumId { get; set; }

    public int TopicId { get; set; }

    public DateTime CreatedOn { get; set; }
}
