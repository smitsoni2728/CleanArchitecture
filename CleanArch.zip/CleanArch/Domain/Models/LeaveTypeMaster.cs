﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class LeaveTypeMaster
{
    public decimal LvtmId { get; set; }

    public string? LvtmTypename { get; set; }
}
