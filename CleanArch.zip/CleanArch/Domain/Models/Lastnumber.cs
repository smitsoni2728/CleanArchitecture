﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Lastnumber
{
    public int LastNumb { get; set; }
}
