﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Pedido
{
    public int Id { get; set; }

    public int Cliente { get; set; }

    public string Vendedor { get; set; } = null!;

    public short Quantidade { get; set; }

    public decimal Valor { get; set; }

    public DateTime Data { get; set; }
}
