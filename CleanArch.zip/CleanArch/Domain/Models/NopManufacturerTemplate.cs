﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopManufacturerTemplate
{
    public int ManufacturerTemplateId { get; set; }

    public string Name { get; set; } = null!;

    public string TemplatePath { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopManufacturer> NopManufacturers { get; set; } = new List<NopManufacturer>();
}
