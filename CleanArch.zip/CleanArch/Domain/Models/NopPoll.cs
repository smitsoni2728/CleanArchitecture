﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopPoll
{
    public int PollId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string SystemKeyword { get; set; } = null!;

    public bool Published { get; set; }

    public bool ShowOnHomePage { get; set; }

    public int DisplayOrder { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual ICollection<NopPollAnswer> NopPollAnswers { get; set; } = new List<NopPollAnswer>();
}
