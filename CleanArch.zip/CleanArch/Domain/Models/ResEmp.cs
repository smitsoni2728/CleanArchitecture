﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResEmp
{
    public int? Iempid { get; set; }

    public string? CempName { get; set; }

    public DateTime? DbirthDate { get; set; }

    public int? Isalary { get; set; }
}
