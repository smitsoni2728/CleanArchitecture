﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class T3
{
    public int? No { get; set; }
}
