﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistAdminMenuRight
{
    public int MenuId { get; set; }

    public int DistributorId { get; set; }

    public bool IsAllowed { get; set; }

    public bool IsAdd { get; set; }

    public bool IsEdit { get; set; }

    public bool IsDelete { get; set; }

    public bool IsPrint { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
