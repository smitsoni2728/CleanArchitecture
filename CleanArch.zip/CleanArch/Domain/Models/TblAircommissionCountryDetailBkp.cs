﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommissionCountryDetailBkp
{
    public int CommCountryDetId { get; set; }

    public int CommissionId { get; set; }

    public bool IsValidFromCountry { get; set; }

    public int CountryId { get; set; }

    public string ExcAllowStationCode { get; set; } = null!;

    public byte OrderNo { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
