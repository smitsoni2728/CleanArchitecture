﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblebusTransaction
{
    public int TarnsId { get; set; }

    public DateTime? BusTransDate { get; set; }

    public decimal? TicketAmt { get; set; }

    public DateTime? TarvelDate { get; set; }

    public string? BusNo { get; set; }

    public string? BusStops { get; set; }
}
