﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCommand
{
    public byte CommandId { get; set; }

    public string? CommandType { get; set; }

    public string? CommandDesc { get; set; }

    public string? CommandProc { get; set; }

    public virtual ICollection<TblHistory> TblHistories { get; set; } = new List<TblHistory>();
}
