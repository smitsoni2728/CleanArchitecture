﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCategory
{
    public int CategoryId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public int TemplateId { get; set; }

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public string MetaTitle { get; set; } = null!;

    public string Sename { get; set; } = null!;

    public int ParentCategoryId { get; set; }

    public int PictureId { get; set; }

    public int PageSize { get; set; }

    public string PriceRanges { get; set; } = null!;

    public bool ShowOnHomePage { get; set; }

    public bool Published { get; set; }

    public bool Deleted { get; set; }

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopCategoryLocalized> NopCategoryLocalizeds { get; set; } = new List<NopCategoryLocalized>();

    public virtual ICollection<NopProductCategoryMapping> NopProductCategoryMappings { get; set; } = new List<NopProductCategoryMapping>();

    public virtual NopCategoryTemplate Template { get; set; } = null!;

    public virtual ICollection<NopDiscount> Discounts { get; set; } = new List<NopDiscount>();
}
