﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDbuserwiseObjectRightsChangedHistory
{
    public int HistoryId { get; set; }

    public string ObjectType { get; set; } = null!;

    public string ObjectNames { get; set; } = null!;

    public string UserName { get; set; } = null!;

    public string GiveRevert { get; set; } = null!;

    public bool IsSelect { get; set; }

    public bool IsInsert { get; set; }

    public bool IsUpdate { get; set; }

    public bool IsDelete { get; set; }

    public bool IsViewDefinition { get; set; }

    public bool IsExecute { get; set; }

    public string ChangedByUserName { get; set; } = null!;

    public string ClientIp { get; set; } = null!;

    public DateTime HistoryDate { get; set; }
}
