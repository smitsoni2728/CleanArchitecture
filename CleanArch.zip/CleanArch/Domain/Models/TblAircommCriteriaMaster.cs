﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommCriteriaMaster
{
    public int CommCriteriaId { get; set; }

    public string CommCriteriaCode { get; set; } = null!;

    public string CommCriteriaDesc { get; set; } = null!;

    public bool IsDomestic { get; set; }

    public bool IsTourCodeWise { get; set; }

    public string TourCode { get; set; } = null!;

    public decimal Commission { get; set; }

    public string Endorsement { get; set; } = null!;

    public string Pnrosifield { get; set; } = null!;

    public string BaggageAllowance { get; set; } = null!;

    public bool IsApiwise { get; set; }

    public int Apiid { get; set; }

    public string AirlineId { get; set; } = null!;

    public string FlightAllowed { get; set; } = null!;

    public string FlightNotAllowed { get; set; } = null!;

    public bool IsCabinClassWise { get; set; }

    public string ClassIds { get; set; } = null!;

    public bool IsBookingClassWise { get; set; }

    public bool IsBookingClassAllowed { get; set; }

    public string BookingClass { get; set; } = null!;

    public bool IsFareBasisCodeWise { get; set; }

    public bool IsFareBasisCodeAllowed { get; set; }

    public string FareBasisCode { get; set; } = null!;

    public bool IsContinentWise { get; set; }

    public bool IsSourceContinent { get; set; }

    public bool IsAllowedSourceContinent { get; set; }

    public string SourceContinentIds { get; set; } = null!;

    public bool IsDestinationContinent { get; set; }

    public bool IsAllowedDestinationContinent { get; set; }

    public string DestinationContinentIds { get; set; } = null!;

    public bool IsCountryWise { get; set; }

    public bool IsStationWise { get; set; }

    public bool IsValidFromStation { get; set; }

    public string ValidFromStationCode { get; set; } = null!;

    public bool IsNotValidFromStation { get; set; }

    public string NotValidFromStationCode { get; set; } = null!;

    public bool IsValidToStation { get; set; }

    public string ValidToStationCode { get; set; } = null!;

    public bool IsNotValidToStation { get; set; }

    public string NotValidToStationCode { get; set; } = null!;

    public bool IsSectorWise { get; set; }

    public bool IsRoutingWise { get; set; }

    public bool IsBookingDateWise { get; set; }

    public bool IsDepartureDateWise { get; set; }

    public bool IsAdvanceReservationWise { get; set; }

    public short AdvanceReservationNoOfDays { get; set; }

    public bool IsRoundTrip { get; set; }

    public bool IsCircularTrip { get; set; }

    public bool IsTotalStopOverWise { get; set; }

    public byte TotNoOfStopOverAllowed { get; set; }

    public decimal ChargePerStopOver { get; set; }

    public bool IsOutboundStopOverWise { get; set; }

    public byte TotNoOfOutboundStopOverAllowed { get; set; }

    public decimal OutboundChargePerStopOver { get; set; }

    public bool IsInboundStopOverWise { get; set; }

    public byte TotNoOfInboundStopOverAllowed { get; set; }

    public decimal InboundChargePerStopOver { get; set; }

    public bool IsMinimumStayWise { get; set; }

    public byte MinStayNoOfDays { get; set; }

    public bool IsMaximumStayWise { get; set; }

    public byte MaxStayNoOfDays { get; set; }

    public bool IsTransferTransitWise { get; set; }

    public byte NoOfTransferTransitAllowed { get; set; }

    public bool IsOpenJawWise { get; set; }

    public bool IsSaleCountryWise { get; set; }

    public bool IsCommTypePercentage { get; set; }

    public decimal CommissionAmt { get; set; }

    public bool IsPlbonMileage { get; set; }

    public bool IataisPaxTotalFlightAmount { get; set; }

    public bool PlbisPaxTotalFlightAmount { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
