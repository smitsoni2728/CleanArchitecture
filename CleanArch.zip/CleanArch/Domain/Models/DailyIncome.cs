﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class DailyIncome
{
    public string? VendorId { get; set; }

    public string? IncomeDay { get; set; }

    public int? IncomeAmount { get; set; }
}
