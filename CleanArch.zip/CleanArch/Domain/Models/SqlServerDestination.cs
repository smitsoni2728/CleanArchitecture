﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class SqlServerDestination
{
    public string? PostOfficeName { get; set; }

    public double? Pincode { get; set; }

    public string? DistrictsName { get; set; }

    public string? CityName { get; set; }

    public string? StateName { get; set; }
}
