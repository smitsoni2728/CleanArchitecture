﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblApimaster
{
    public int Apiid { get; set; }

    public string Apiname { get; set; } = null!;

    public string Apidesc { get; set; } = null!;

    public string Apiurl { get; set; } = null!;

    public string Address1 { get; set; } = null!;

    public string Address2 { get; set; } = null!;

    public string Address3 { get; set; } = null!;

    public int CountryId { get; set; }

    public int StateId { get; set; }

    public int CityId { get; set; }

    public string? PinCode { get; set; }

    public bool Isactive { get; set; }
}
