﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class MyName
{
    public string? Name { get; set; }
}
