﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopLanguage
{
    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string LanguageCulture { get; set; } = null!;

    public string FlagImageFileName { get; set; } = null!;

    public bool Published { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopBlogPost> NopBlogPosts { get; set; } = new List<NopBlogPost>();

    public virtual ICollection<NopCategoryLocalized> NopCategoryLocalizeds { get; set; } = new List<NopCategoryLocalized>();

    public virtual ICollection<NopCheckoutAttributeLocalized> NopCheckoutAttributeLocalizeds { get; set; } = new List<NopCheckoutAttributeLocalized>();

    public virtual ICollection<NopCheckoutAttributeValueLocalized> NopCheckoutAttributeValueLocalizeds { get; set; } = new List<NopCheckoutAttributeValueLocalized>();

    public virtual ICollection<NopLocaleStringResource> NopLocaleStringResources { get; set; } = new List<NopLocaleStringResource>();

    public virtual ICollection<NopManufacturerLocalized> NopManufacturerLocalizeds { get; set; } = new List<NopManufacturerLocalized>();

    public virtual ICollection<NopMessageTemplateLocalized> NopMessageTemplateLocalizeds { get; set; } = new List<NopMessageTemplateLocalized>();

    public virtual ICollection<NopNews> NopNews { get; set; } = new List<NopNews>();

    public virtual ICollection<NopPoll> NopPolls { get; set; } = new List<NopPoll>();

    public virtual ICollection<NopProductAttributeLocalized> NopProductAttributeLocalizeds { get; set; } = new List<NopProductAttributeLocalized>();

    public virtual ICollection<NopProductLocalized> NopProductLocalizeds { get; set; } = new List<NopProductLocalized>();

    public virtual ICollection<NopProductVariantAttributeValueLocalized> NopProductVariantAttributeValueLocalizeds { get; set; } = new List<NopProductVariantAttributeValueLocalized>();

    public virtual ICollection<NopProductVariantLocalized> NopProductVariantLocalizeds { get; set; } = new List<NopProductVariantLocalized>();

    public virtual ICollection<NopSpecificationAttributeLocalized> NopSpecificationAttributeLocalizeds { get; set; } = new List<NopSpecificationAttributeLocalized>();

    public virtual ICollection<NopSpecificationAttributeOptionLocalized> NopSpecificationAttributeOptionLocalizeds { get; set; } = new List<NopSpecificationAttributeOptionLocalized>();

    public virtual ICollection<NopTopicLocalized> NopTopicLocalizeds { get; set; } = new List<NopTopicLocalized>();
}
