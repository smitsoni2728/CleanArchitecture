﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductLocalized
{
    public int ProductLocalizedId { get; set; }

    public int ProductId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string ShortDescription { get; set; } = null!;

    public string FullDescription { get; set; } = null!;

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public string MetaTitle { get; set; } = null!;

    public string Sename { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopProduct Product { get; set; } = null!;
}
