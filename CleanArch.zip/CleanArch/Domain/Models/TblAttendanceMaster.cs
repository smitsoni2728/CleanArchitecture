﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAttendanceMaster
{
    public int AttendanceId { get; set; }

    public int Empid { get; set; }

    public DateTime AttDate { get; set; }

    public bool IsFullAt { get; set; }

    public bool IshalfLeaveAt { get; set; }

    public bool IsFullLeaveAt { get; set; }

    public bool IstowTimeLateAt { get; set; }

    public string CreateBy { get; set; } = null!;

    public DateTime CreateDateTime { get; set; }

    public string CreateIp { get; set; } = null!;

    public string UpdateBy { get; set; } = null!;

    public DateTime UpdateDateTime { get; set; }

    public string UpdateIp { get; set; } = null!;
}
