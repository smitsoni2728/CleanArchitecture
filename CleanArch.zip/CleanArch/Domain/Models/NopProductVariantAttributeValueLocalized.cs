﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariantAttributeValueLocalized
{
    public int ProductVariantAttributeValueLocalizedId { get; set; }

    public int ProductVariantAttributeValueId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopProductVariantAttributeValue ProductVariantAttributeValue { get; set; } = null!;
}
