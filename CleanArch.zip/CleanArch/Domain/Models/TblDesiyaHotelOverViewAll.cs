﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaHotelOverViewAll
{
    public string? VendorName { get; set; }

    public string? VendorId { get; set; }

    public string? HotelClass { get; set; }

    public string? Location { get; set; }

    public string? City { get; set; }

    public string? Country { get; set; }

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? Area { get; set; }

    public string? Address { get; set; }

    public string? HotelOverview { get; set; }

    public string? ReviewRating { get; set; }

    public string? ReviewCount { get; set; }

    public string? Latitude { get; set; }

    public string? Longitude { get; set; }

    public string? DefaultCheckInTime { get; set; }

    public string? DefaultCheckOutTime { get; set; }

    public string? HotelStar { get; set; }

    public string? HotelGroupId { get; set; }

    public string? HotelGroupName { get; set; }

    public string? ImagePath { get; set; }

    public string? HotelSearchKey { get; set; }

    public string? AreaSeoId { get; set; }

    public string? CityZone { get; set; }

    public string? WeekdayRank { get; set; }

    public string? WeekendRank { get; set; }

    public string? TgroomsType { get; set; }

    public string? YatraTripleGurantee { get; set; }

    public string? OriginalVendorName { get; set; }

    public string? OriginalVendorId { get; set; }
}
