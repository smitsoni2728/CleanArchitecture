﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopMessageTemplateLocalized
{
    public int MessageTemplateLocalizedId { get; set; }

    public int MessageTemplateId { get; set; }

    public int LanguageId { get; set; }

    public string BccemailAddresses { get; set; } = null!;

    public string Subject { get; set; } = null!;

    public string Body { get; set; } = null!;

    public bool? IsActive { get; set; }

    public int EmailAccountId { get; set; }

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopMessageTemplate MessageTemplate { get; set; } = null!;
}
