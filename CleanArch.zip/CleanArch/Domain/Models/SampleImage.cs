﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class SampleImage
{
    public int? ImageId { get; set; }

    public byte[]? ImageName { get; set; }
}
