﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDepartmentTypeMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int DepartmentTypeId { get; set; }

    public string OlddepartmentTypeCode { get; set; } = null!;

    public string OlddepartmentTypeName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewdepartmentTypeCode { get; set; } = null!;

    public string NewdepartmentTypeName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
