﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponEventMaster
{
    public int EventId { get; set; }

    public string EventName { get; set; } = null!;

    public string EventPersonName { get; set; } = null!;

    public string EventPersonMobileNo { get; set; } = null!;

    public string EventPersonEmailId { get; set; } = null!;

    public string EventStartDate { get; set; } = null!;

    public string EventEndDate { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
