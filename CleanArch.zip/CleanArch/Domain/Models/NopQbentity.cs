﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopQbentity
{
    public int EntityId { get; set; }

    public string QbentityId { get; set; } = null!;

    public int EntityTypeId { get; set; }

    public int NopEntityId { get; set; }

    public int SynStateId { get; set; }

    public string SeqNum { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }
}
