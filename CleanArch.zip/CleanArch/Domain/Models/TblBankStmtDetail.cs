﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBankStmtDetail
{
    public int BankStmtDetId { get; set; }

    public int BankStmtId { get; set; }

    public string Txnid { get; set; } = null!;

    public string DistributorCode { get; set; } = null!;

    public decimal Amount { get; set; }

    public int Requestid { get; set; }

    public bool IsProcessed { get; set; }

    public DateTime ProcessDateTime { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
