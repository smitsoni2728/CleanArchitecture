﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBooksType
{
    public int BookTypeId { get; set; }

    public int BookId { get; set; }

    public string BookName { get; set; } = null!;

    public bool Isactive { get; set; }

    public int CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public int CreateIp { get; set; }

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public int UpdateIp { get; set; }
}
