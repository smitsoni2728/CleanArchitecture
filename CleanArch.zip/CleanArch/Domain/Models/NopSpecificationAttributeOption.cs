﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopSpecificationAttributeOption
{
    public int SpecificationAttributeOptionId { get; set; }

    public int SpecificationAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopProductSpecificationAttributeMapping> NopProductSpecificationAttributeMappings { get; set; } = new List<NopProductSpecificationAttributeMapping>();

    public virtual ICollection<NopSpecificationAttributeOptionLocalized> NopSpecificationAttributeOptionLocalizeds { get; set; } = new List<NopSpecificationAttributeOptionLocalized>();

    public virtual NopSpecificationAttribute SpecificationAttribute { get; set; } = null!;
}
