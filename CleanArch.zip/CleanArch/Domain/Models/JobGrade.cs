﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class JobGrade
{
    public string? Grade { get; set; }

    public decimal? Minsal { get; set; }

    public decimal? Maxsal { get; set; }
}
