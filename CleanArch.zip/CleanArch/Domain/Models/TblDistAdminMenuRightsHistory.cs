﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistAdminMenuRightsHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int MenuId { get; set; }

    public int DistributorId { get; set; }

    public bool OldisAllowed { get; set; }

    public bool OldisAdd { get; set; }

    public bool OldisEdit { get; set; }

    public bool OldisDelete { get; set; }

    public bool OldisPrint { get; set; }

    public bool NewisAllowed { get; set; }

    public bool NewisAdd { get; set; }

    public bool NewisEdit { get; set; }

    public bool NewisDelete { get; set; }

    public bool NewisPrint { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
