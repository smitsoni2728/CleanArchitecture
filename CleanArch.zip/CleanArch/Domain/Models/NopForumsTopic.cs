﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopForumsTopic
{
    public int TopicId { get; set; }

    public int ForumId { get; set; }

    public int UserId { get; set; }

    public int TopicTypeId { get; set; }

    public string Subject { get; set; } = null!;

    public int NumPosts { get; set; }

    public int Views { get; set; }

    public int LastPostId { get; set; }

    public int LastPostUserId { get; set; }

    public DateTime? LastPostTime { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopForumsForum Forum { get; set; } = null!;

    public virtual ICollection<NopForumsPost> NopForumsPosts { get; set; } = new List<NopForumsPost>();
}
