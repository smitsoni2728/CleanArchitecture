﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmaiL
{
    public int? Id { get; set; }
}
