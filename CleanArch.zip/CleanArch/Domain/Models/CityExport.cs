﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class CityExport
{
    public int ExportId { get; set; }

    public DateTime ExportTime { get; set; }
}
