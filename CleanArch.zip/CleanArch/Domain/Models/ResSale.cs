﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResSale
{
    public int IsaleId { get; set; }

    public string? CsaleProduct { get; set; }

    public int? ItotalSale { get; set; }
}
