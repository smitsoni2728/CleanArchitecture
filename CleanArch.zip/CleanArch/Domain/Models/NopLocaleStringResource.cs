﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopLocaleStringResource
{
    public int LocaleStringResourceId { get; set; }

    public int LanguageId { get; set; }

    public string ResourceName { get; set; } = null!;

    public string ResourceValue { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;
}
