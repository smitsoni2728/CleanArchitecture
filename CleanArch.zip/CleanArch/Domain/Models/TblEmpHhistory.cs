﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmpHhistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int EmpId { get; set; }

    public string OldempCode { get; set; } = null!;

    public string OldempName { get; set; } = null!;

    public string Oldaddress { get; set; } = null!;

    public DateTime OldbirthDate { get; set; }

    public DateTime OldjoiningDate { get; set; }

    public decimal Oldsalary { get; set; }

    public bool OldisActive { get; set; }

    public string NewempCode { get; set; } = null!;

    public string NewempName { get; set; } = null!;

    public string Newaddress { get; set; } = null!;

    public DateTime NewbirthDate { get; set; }

    public DateTime NewjoiningDate { get; set; }

    public decimal Newsalary { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
