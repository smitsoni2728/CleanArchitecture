﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopDiscountUsageHistory
{
    public int DiscountUsageHistoryId { get; set; }

    public int DiscountId { get; set; }

    public int CustomerId { get; set; }

    public int OrderId { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;

    public virtual NopDiscount Discount { get; set; } = null!;

    public virtual NopOrder Order { get; set; } = null!;
}
