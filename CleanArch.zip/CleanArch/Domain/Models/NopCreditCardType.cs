﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCreditCardType
{
    public int CreditCardTypeId { get; set; }

    public string Name { get; set; } = null!;

    public string SystemKeyword { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public bool Deleted { get; set; }
}
