﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaImageUrl
{
    public string? VendorId { get; set; }

    public string? ImageUrl { get; set; }

    public string? ContentTitle { get; set; }
}
