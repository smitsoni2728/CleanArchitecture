﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponOrderDetail
{
    public int CouponOrderDetId { get; set; }

    public int CouponOrderReqId { get; set; }

    public int CouponOrderPaymentId { get; set; }

    public int CouponDetId { get; set; }

    public int VendorId { get; set; }

    public int TotalCoupon { get; set; }

    public decimal TotalAmount { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
