﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopTaxRate
{
    public int TaxRateId { get; set; }

    public int TaxCategoryId { get; set; }

    public int CountryId { get; set; }

    public int StateProvinceId { get; set; }

    public string Zip { get; set; } = null!;

    public decimal Percentage { get; set; }

    public virtual NopCountry Country { get; set; } = null!;

    public virtual NopTaxCategory TaxCategory { get; set; } = null!;
}
