﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopTopic
{
    public int TopicId { get; set; }

    public string Name { get; set; } = null!;

    public bool IsPasswordProtected { get; set; }

    public string Password { get; set; } = null!;

    public bool IncludeInSitemap { get; set; }

    public virtual ICollection<NopTopicLocalized> NopTopicLocalizeds { get; set; } = new List<NopTopicLocalized>();
}
