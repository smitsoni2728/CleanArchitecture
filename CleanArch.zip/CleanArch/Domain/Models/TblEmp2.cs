﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmp2
{
    public int EmpId { get; set; }

    public string EmpUserName { get; set; } = null!;

    public string EmpUserPsw { get; set; } = null!;
}
