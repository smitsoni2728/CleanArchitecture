﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCoupon1
{
    public int CouponId { get; set; }

    public int? CustomerId { get; set; }

    public string? Organizer { get; set; }

    public string? CouponCode { get; set; }

    public string? Start { get; set; }

    public string? End { get; set; }
}
