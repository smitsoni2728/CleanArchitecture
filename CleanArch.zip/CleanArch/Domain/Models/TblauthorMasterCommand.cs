﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblauthorMasterCommand
{
    public byte? CommandId { get; set; }

    public string? CommandType { get; set; }

    public string? CommandDesc { get; set; }

    public string? CommandProc { get; set; }
}
