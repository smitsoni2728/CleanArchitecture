﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class MyTable12Nov
{
    public int Column1 { get; set; }

    public int? Column2 { get; set; }
}
