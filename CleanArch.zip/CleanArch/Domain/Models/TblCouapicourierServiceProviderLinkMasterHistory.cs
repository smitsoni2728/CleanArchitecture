﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouapicourierServiceProviderLinkMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int ApicourierServiceProviderLinkId { get; set; }

    public int Oldapiid { get; set; }

    public int OldcourierServiceProviderId { get; set; }

    public string Oldapivalue { get; set; } = null!;

    public bool OldisActive { get; set; }

    public int Newapiid { get; set; }

    public int NewcourierServiceProviderId { get; set; }

    public string Newapivalue { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
