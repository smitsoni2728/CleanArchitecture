﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommissionCodeShareDetail
{
    public int CommCodeShareDetId { get; set; }

    public bool IsCodeShareAllowed { get; set; }

    public int CodeShareAirlineId { get; set; }

    public string CodeShareFlightAllowed { get; set; } = null!;

    public string CodeShareFlightNotAllowed { get; set; } = null!;

    public byte OrderNo { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public int CommCriteriaId { get; set; }
}
