﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopTaxCategory
{
    public int TaxCategoryId { get; set; }

    public string Name { get; set; } = null!;

    public int? DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopTaxRate> NopTaxRates { get; set; } = new List<NopTaxRate>();
}
