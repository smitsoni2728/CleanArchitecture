﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouapimasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int Apiid { get; set; }

    public string Oldapiname { get; set; } = null!;

    public string OldemailId { get; set; } = null!;

    public string OldmobileNo { get; set; } = null!;

    public string OldapiuserId { get; set; } = null!;

    public string Oldapipassword { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string Newapiname { get; set; } = null!;

    public string NewemailId { get; set; } = null!;

    public string NewmobileNo { get; set; } = null!;

    public string NewapiuserId { get; set; } = null!;

    public string Newapipassword { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
