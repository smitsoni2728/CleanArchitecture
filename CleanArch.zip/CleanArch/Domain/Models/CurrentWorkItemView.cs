﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class CurrentWorkItemView
{
    public string Id { get; set; } = null!;

    public string WorkItemType { get; set; } = null!;

    public string Title { get; set; } = null!;

    public string? Description { get; set; }

    public string? AssignedTo { get; set; }

    public string State { get; set; } = null!;

    public string Reason { get; set; } = null!;

    public int? StoryPoints { get; set; }

    public int? Priority { get; set; }

    public int? Rank { get; set; }
}
