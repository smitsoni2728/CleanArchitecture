﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmployeeTree
{
    public string EmployeeId { get; set; } = null!;

    public string EmployeeName { get; set; } = null!;

    public string BossId { get; set; } = null!;
}
