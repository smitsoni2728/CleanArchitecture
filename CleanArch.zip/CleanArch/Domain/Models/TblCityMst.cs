﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCityMst
{
    public int CityId { get; set; }

    public string CityCode { get; set; } = null!;

    public string CityName { get; set; } = null!;

    public bool IsActive { get; set; }

    public string Remark { get; set; } = null!;

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public bool Isac { get; set; }
}
