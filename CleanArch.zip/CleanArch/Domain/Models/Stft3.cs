﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Stft3
{
    public int? T1 { get; set; }
}
