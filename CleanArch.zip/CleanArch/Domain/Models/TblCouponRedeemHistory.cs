﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponRedeemHistory
{
    public int CouponRedeemId { get; set; }

    public int CouponId { get; set; }

    public int CustomerId { get; set; }

    public int VendorId { get; set; }

    public int EventId { get; set; }

    public string CouponCode { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;
}
