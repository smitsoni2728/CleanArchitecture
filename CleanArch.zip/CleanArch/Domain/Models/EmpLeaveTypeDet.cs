﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmpLeaveTypeDet
{
    public decimal? EltdLeaveid { get; set; }

    public decimal? EltdLeavetypeid { get; set; }
}
