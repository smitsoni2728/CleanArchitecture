﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDhavanEntry
{
    public int Id { get; set; }

    public string? CreateCode { get; set; }

    public string? Ename { get; set; }

    public byte? EntryId { get; set; }

    public string? EntryType { get; set; }

    public DateTime? EntryDate { get; set; }

    public string? EntryZone { get; set; }
}
