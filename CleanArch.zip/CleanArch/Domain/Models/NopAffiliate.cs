﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopAffiliate
{
    public int AffiliateId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string MiddleName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string FaxNumber { get; set; } = null!;

    public string Company { get; set; } = null!;

    public string Address1 { get; set; } = null!;

    public string Address2 { get; set; } = null!;

    public string City { get; set; } = null!;

    public string StateProvince { get; set; } = null!;

    public string ZipPostalCode { get; set; } = null!;

    public int CountryId { get; set; }

    public bool Active { get; set; }

    public bool Deleted { get; set; }
}
