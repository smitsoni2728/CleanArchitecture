﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCustomerRole
{
    public int CustomerRoleId { get; set; }

    public string Name { get; set; } = null!;

    public bool FreeShipping { get; set; }

    public bool TaxExempt { get; set; }

    public bool Active { get; set; }

    public bool Deleted { get; set; }

    public virtual ICollection<NopAclperObject> NopAclperObjects { get; set; } = new List<NopAclperObject>();

    public virtual ICollection<NopAcl> NopAcls { get; set; } = new List<NopAcl>();

    public virtual ICollection<NopCustomerRoleProductPrice> NopCustomerRoleProductPrices { get; set; } = new List<NopCustomerRoleProductPrice>();

    public virtual ICollection<NopCustomer> Customers { get; set; } = new List<NopCustomer>();

    public virtual ICollection<NopDiscount> Discounts { get; set; } = new List<NopDiscount>();
}
