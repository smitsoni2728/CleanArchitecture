﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResEmployee
{
    public int IempId { get; set; }

    public int? IdeptId { get; set; }

    public string? CdeptName { get; set; }

    public int? Salary { get; set; }
}
