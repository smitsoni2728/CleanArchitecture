﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCompany
{
    public string StrCompanyCode1 { get; set; } = null!;

    public string StrCompanyName1 { get; set; } = null!;

    public DateTime DtmFromDate { get; set; }

    public DateTime DtmTodate { get; set; }

    public DateTime DtmAccClosingDate { get; set; }

    public string StrControl { get; set; } = null!;

    public string StrCreateId { get; set; } = null!;

    public DateTime StrCreateDateTime { get; set; }

    public string StrUpdId { get; set; } = null!;

    public DateTime StrUpdDateTime { get; set; }

    public string StrCreateIpaddress { get; set; } = null!;

    public string StrUpdateIpaddress { get; set; } = null!;

    public int IdKey { get; set; }
}
