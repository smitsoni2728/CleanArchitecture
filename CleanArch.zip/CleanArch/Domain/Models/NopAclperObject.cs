﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopAclperObject
{
    public int AclperObjectId { get; set; }

    public int ObjectId { get; set; }

    public int ObjectTypeId { get; set; }

    public int CustomerRoleId { get; set; }

    public bool Deny { get; set; }

    public virtual NopCustomerRole CustomerRole { get; set; } = null!;
}
