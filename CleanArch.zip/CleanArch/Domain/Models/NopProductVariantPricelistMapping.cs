﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariantPricelistMapping
{
    public int ProductVariantPricelistId { get; set; }

    public int ProductVariantId { get; set; }

    public int PricelistId { get; set; }

    public int PriceAdjustmentTypeId { get; set; }

    public decimal PriceAdjustment { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopPricelist Pricelist { get; set; } = null!;

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
