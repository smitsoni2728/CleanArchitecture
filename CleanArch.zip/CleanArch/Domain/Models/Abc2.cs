﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Abc2
{
    public string A { get; set; } = null!;

    public int? A1 { get; set; }

    public int? B { get; set; }

    public string Tname { get; set; } = null!;

    public string? Cc { get; set; }

    public int G1 { get; set; }

    public byte Tt { get; set; }

    public string? Sss1 { get; set; }

    public string Intapicountrywise { get; set; } = null!;

    public string GalCredentials { get; set; } = null!;

    public string Iwise { get; set; } = null!;

    public string Gatials { get; set; } = null!;
}
