﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Mobile
{
    public int Model { get; set; }

    public string Name { get; set; } = null!;

    public decimal Price { get; set; }

    public DateTime? CreateDateTime { get; set; }
}
