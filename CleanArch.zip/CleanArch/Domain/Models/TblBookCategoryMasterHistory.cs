﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBookCategoryMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int BookCategoryId { get; set; }

    public string OldbookCategoryCode { get; set; } = null!;

    public string OldbookCategoryName { get; set; } = null!;

    public int OldbookAmount { get; set; }

    public decimal OldbookPrice { get; set; }

    public bool OldisActive { get; set; }

    public string NewbookCategoryCode { get; set; } = null!;

    public string NewbookCategoryName { get; set; } = null!;

    public int NewbookAmount { get; set; }

    public decimal NewbookPrice { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
