﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorLimitApprovalDetailsMax
{
    public int MaxId { get; set; }
}
