﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBankMaster1
{
    public int Bankid { get; set; }
}
