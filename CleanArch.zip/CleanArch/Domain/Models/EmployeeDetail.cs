﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmployeeDetail
{
    public int EmpId { get; set; }

    public string? Name { get; set; }

    public decimal? Salary { get; set; }

    public string? Designation { get; set; }
}
