﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class T1emp
{
    public int IntEmpId { get; set; }

    public string StrEmpCode { get; set; } = null!;

    public string StrEmpName { get; set; } = null!;
}
