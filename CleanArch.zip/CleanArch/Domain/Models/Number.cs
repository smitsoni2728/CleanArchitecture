﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Number
{
    public int? Number1 { get; set; }
}
