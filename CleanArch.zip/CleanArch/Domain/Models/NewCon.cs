﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NewCon
{
    public int? Sss { get; set; }
}
