﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopTierPrice
{
    public int TierPriceId { get; set; }

    public int ProductVariantId { get; set; }

    public int Quantity { get; set; }

    public decimal Price { get; set; }

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
