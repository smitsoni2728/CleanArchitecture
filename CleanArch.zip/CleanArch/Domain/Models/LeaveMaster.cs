﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class LeaveMaster
{
    public decimal LmId { get; set; }

    public decimal? LmEmpid { get; set; }

    public DateTime? LmDateapplied { get; set; }

    public decimal? LmLeavetypeid { get; set; }

    public DateTime? LmLeavefrom { get; set; }

    public DateTime? LmLeaveto { get; set; }

    public string? LmReason { get; set; }

    public decimal? LmApprovebyid { get; set; }

    public string? LmStatus { get; set; }

    public DateTime? LmCreateddate { get; set; }

    public decimal? LmCreatedid { get; set; }

    public DateTime? LmModifieddate { get; set; }

    public decimal? LmModifiedid { get; set; }
}
