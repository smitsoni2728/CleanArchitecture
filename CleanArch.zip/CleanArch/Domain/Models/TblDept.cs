﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDept
{
    public int? Iempid { get; set; }

    public int? Ideptid { get; set; }

    public string? Cdeptname { get; set; }
}
