﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBanksMasterHistory
{
    public int HistoryId { get; set; }

    public int CommandId { get; set; }

    public int BankId { get; set; }

    public string OldbankCode { get; set; } = null!;

    public string OldbankName { get; set; } = null!;

    public string OldbankWebSite { get; set; } = null!;

    public string Oldaddress { get; set; } = null!;

    public string Oldcity { get; set; } = null!;

    public string Oldemail { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewbankCode { get; set; } = null!;

    public string NewbankName { get; set; } = null!;

    public string NewbankWebSite { get; set; } = null!;

    public string Newaddress { get; set; } = null!;

    public string Newcity { get; set; } = null!;

    public string Newemail { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
