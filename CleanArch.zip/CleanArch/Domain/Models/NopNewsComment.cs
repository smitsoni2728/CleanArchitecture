﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopNewsComment
{
    public int NewsCommentId { get; set; }

    public int NewsId { get; set; }

    public int CustomerId { get; set; }

    public string Ipaddress { get; set; } = null!;

    public string Title { get; set; } = null!;

    public string Comment { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public virtual NopNews News { get; set; } = null!;
}
