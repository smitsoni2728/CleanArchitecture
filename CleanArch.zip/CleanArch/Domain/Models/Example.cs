﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Example
{
    public int Id { get; set; }

    public string? Name { get; set; }
}
