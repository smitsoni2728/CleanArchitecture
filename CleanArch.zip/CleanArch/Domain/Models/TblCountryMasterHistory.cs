﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCountryMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CountryId { get; set; }

    public string? Oldcountrycode { get; set; }

    public string Oldcountryname { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string? Newcountrycode { get; set; }

    public string Newcountryname { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
