﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopNewsLetterSubscription
{
    public int NewsLetterSubscriptionId { get; set; }

    public Guid NewsLetterSubscriptionGuid { get; set; }

    public string Email { get; set; } = null!;

    public bool Active { get; set; }

    public DateTime CreatedOn { get; set; }
}
