﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopRecurringPayment
{
    public int RecurringPaymentId { get; set; }

    public int InitialOrderId { get; set; }

    public int CycleLength { get; set; }

    public int CyclePeriod { get; set; }

    public int TotalCycles { get; set; }

    public DateTime StartDate { get; set; }

    public bool IsActive { get; set; }

    public bool Deleted { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual ICollection<NopRecurringPaymentHistory> NopRecurringPaymentHistories { get; set; } = new List<NopRecurringPaymentHistory>();
}
