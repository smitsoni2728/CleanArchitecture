﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDob
{
    public int Id { get; set; }

    public DateTime DateOfBirth { get; set; }
}
