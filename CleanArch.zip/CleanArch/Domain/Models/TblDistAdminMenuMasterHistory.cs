﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistAdminMenuMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int MenuId { get; set; }

    public int OldparentMenuId { get; set; }

    public string OldmenuCaption { get; set; } = null!;

    public string OldmenuControlName { get; set; } = null!;

    public byte OldmenuLevel { get; set; }

    public byte OldorderNo { get; set; }

    public string OldlogoUrl { get; set; } = null!;

    public bool OldisNewWindow { get; set; }

    public bool OldisActive { get; set; }

    public byte OldsubMenuNo { get; set; }

    public byte OldtotSubMenu { get; set; }

    public string OldmenuKey { get; set; } = null!;

    public int NewparentMenuId { get; set; }

    public string NewmenuCaption { get; set; } = null!;

    public string NewmenuControlName { get; set; } = null!;

    public byte NewmenuLevel { get; set; }

    public byte NeworderNo { get; set; }

    public string NewlogoUrl { get; set; } = null!;

    public bool NewisNewWindow { get; set; }

    public bool NewisActive { get; set; }

    public byte NewsubMenuNo { get; set; }

    public byte NewtotSubMenu { get; set; }

    public string NewmenuKey { get; set; } = null!;

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public string OldmenuToolTip { get; set; } = null!;

    public string NewmenuToolTip { get; set; } = null!;
}
