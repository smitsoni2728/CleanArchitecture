﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopPollVotingRecord
{
    public int PollVotingRecordId { get; set; }

    public int PollAnswerId { get; set; }

    public int CustomerId { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;

    public virtual NopPollAnswer PollAnswer { get; set; } = null!;
}
