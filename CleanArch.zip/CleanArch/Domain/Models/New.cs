﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class New
{
    public byte[] Image1 { get; set; } = null!;

    public string MaxCol { get; set; } = null!;
}
