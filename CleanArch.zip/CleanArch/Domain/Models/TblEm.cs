﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEm
{
    public int EmpId { get; set; }

    public string EmpName { get; set; } = null!;

    public DateTime EmpJoiningDate { get; set; }

    public decimal EmpSalary { get; set; }
}
