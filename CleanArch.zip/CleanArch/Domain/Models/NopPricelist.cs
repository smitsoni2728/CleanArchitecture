﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopPricelist
{
    public int PricelistId { get; set; }

    public int ExportModeId { get; set; }

    public int ExportTypeId { get; set; }

    public int AffiliateId { get; set; }

    public string DisplayName { get; set; } = null!;

    public string ShortName { get; set; } = null!;

    public string PricelistGuid { get; set; } = null!;

    public int CacheTime { get; set; }

    public string FormatLocalization { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string AdminNotes { get; set; } = null!;

    public string Header { get; set; } = null!;

    public string Body { get; set; } = null!;

    public string Footer { get; set; } = null!;

    public int PriceAdjustmentTypeId { get; set; }

    public decimal PriceAdjustment { get; set; }

    public bool OverrideIndivAdjustment { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopProductVariantPricelistMapping> NopProductVariantPricelistMappings { get; set; } = new List<NopProductVariantPricelistMapping>();
}
