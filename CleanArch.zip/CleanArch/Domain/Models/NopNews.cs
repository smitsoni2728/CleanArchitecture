﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopNews
{
    public int NewsId { get; set; }

    public int LanguageId { get; set; }

    public string Title { get; set; } = null!;

    public string Short { get; set; } = null!;

    public string Full { get; set; } = null!;

    public bool Published { get; set; }

    public bool AllowComments { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual ICollection<NopNewsComment> NopNewsComments { get; set; } = new List<NopNewsComment>();
}
