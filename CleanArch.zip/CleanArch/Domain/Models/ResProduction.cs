﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResProduction
{
    public int? IproId { get; set; }

    public string? CproName { get; set; }

    public int? IproPrice { get; set; }
}
