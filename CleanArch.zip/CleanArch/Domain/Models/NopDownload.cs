﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopDownload
{
    public int DownloadId { get; set; }

    public bool UseDownloadUrl { get; set; }

    public string DownloadUrl { get; set; } = null!;

    public byte[]? DownloadBinary { get; set; }

    public string ContentType { get; set; } = null!;

    public string Filename { get; set; } = null!;

    public string Extension { get; set; } = null!;

    public bool IsNew { get; set; }
}
