﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductPicture
{
    public int ProductPictureId { get; set; }

    public int ProductId { get; set; }

    public int PictureId { get; set; }

    public int DisplayOrder { get; set; }

    public virtual NopPicture Picture { get; set; } = null!;

    public virtual NopProduct Product { get; set; } = null!;
}
