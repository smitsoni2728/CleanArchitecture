﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopBannedIpNetwork
{
    public int BannedIpNetworkId { get; set; }

    public string StartAddress { get; set; } = null!;

    public string EndAddress { get; set; } = null!;

    public string? Comment { get; set; }

    public string? IpException { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }
}
