﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Ossa
{
    public double? Sno { get; set; }

    public double? Id { get; set; }

    public string? Userid { get; set; }

    public string? Passwrd { get; set; }

    public string? Firstname { get; set; }

    public string? Middlename { get; set; }

    public string? Lastname { get; set; }

    public string? Corporatename { get; set; }

    public string? Officeaddressline1 { get; set; }

    public string? Officeaddressline2 { get; set; }

    public string? Officecity { get; set; }

    public string? Officestate { get; set; }

    public string? Officecountry { get; set; }

    public double? Officepin { get; set; }

    public double? Officephone { get; set; }

    public double? Officephoneext { get; set; }

    public double? Officefax { get; set; }

    public string? Email { get; set; }

    public string? Residaddressline1 { get; set; }

    public string? Residaddressline2 { get; set; }

    public string? Residcity { get; set; }

    public string? Residstate { get; set; }

    public string? Residcountry { get; set; }

    public double? Residpin { get; set; }

    public double? Residphone { get; set; }
}
