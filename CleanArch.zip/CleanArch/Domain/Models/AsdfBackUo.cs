﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AsdfBackUo
{
    public int CommandId { get; set; }

    public short? Aaaaa { get; set; }

    public string CommandType { get; set; } = null!;

    public string CommandDesc { get; set; } = null!;

    public string CommandProc { get; set; } = null!;
}
