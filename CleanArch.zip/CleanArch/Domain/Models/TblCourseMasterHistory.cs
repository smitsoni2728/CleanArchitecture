﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCourseMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CourseId { get; set; }

    public string OldcourseCode { get; set; } = null!;

    public string OldcourseName { get; set; } = null!;

    public string OldcourseDescription { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewcourseCode { get; set; } = null!;

    public string NewcourseName { get; set; } = null!;

    public string NewcourseDescription { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
