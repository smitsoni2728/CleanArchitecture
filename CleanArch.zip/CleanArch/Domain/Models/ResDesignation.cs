﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResDesignation
{
    public int? Ideptid { get; set; }

    public string? CdesignName { get; set; }
}
