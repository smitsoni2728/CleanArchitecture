﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDiscount
{
    public int Id { get; set; }

    public string? DName { get; set; }

    public string? DCouponCode { get; set; }

    public string? DAmount { get; set; }

    public string? DStatus { get; set; }

    public string? DEvent { get; set; }
}
