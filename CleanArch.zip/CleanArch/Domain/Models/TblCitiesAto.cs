﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCitiesAto
{
    public int CityId { get; set; }

    public string CityCode { get; set; } = null!;

    public string CityName { get; set; } = null!;

    public int StateId { get; set; }

    public int DisplayOrder { get; set; }

    public bool IsActive { get; set; }

    public byte CommnadId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreateDateTime { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdatedBy { get; set; }

    public DateTime UpdateTime { get; set; }

    public string UpdateIp { get; set; } = null!;
}
