﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAvl16feb2011
{
    public string? Column0 { get; set; }

    public string? Column1 { get; set; }

    public string? Column2 { get; set; }

    public string? Column3 { get; set; }

    public string? Column4 { get; set; }
}
