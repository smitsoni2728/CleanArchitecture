﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCategoryLocalized
{
    public int CategoryLocalizedId { get; set; }

    public int CategoryId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public string MetaTitle { get; set; } = null!;

    public string Sename { get; set; } = null!;

    public virtual NopCategory Category { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;
}
