﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class DscCategoryManufacturerCount
{
    public int CategoryId { get; set; }

    public int ManufacturerId { get; set; }

    public int Count { get; set; }

    public virtual DscCategory Category { get; set; } = null!;

    public virtual DscManufacturer Manufacturer { get; set; } = null!;
}
