﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AMgmtAbc
{
    public string A { get; set; } = null!;

    public int A1 { get; set; }

    public int B { get; set; }
}
