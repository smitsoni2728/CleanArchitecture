﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopShippingByTotal
{
    public int ShippingByTotalId { get; set; }

    public int ShippingMethodId { get; set; }

    public decimal From { get; set; }

    public decimal To { get; set; }

    public bool UsePercentage { get; set; }

    public decimal ShippingChargePercentage { get; set; }

    public decimal ShippingChargeAmount { get; set; }

    public virtual NopShippingMethod ShippingMethod { get; set; } = null!;
}
