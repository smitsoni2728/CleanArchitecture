﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommCriteriaMasterHistory
{
    public int HistoryId { get; set; }

    public int CommandId { get; set; }

    public int CommCriteriaId { get; set; }

    public string OldcommCriteriaCode { get; set; } = null!;

    public string OldcommCriteriaDesc { get; set; } = null!;

    public bool OldisDomestic { get; set; }

    public bool OldisTourCodeWise { get; set; }

    public string OldtourCode { get; set; } = null!;

    public decimal Oldcommission { get; set; }

    public string Oldendorsement { get; set; } = null!;

    public string Oldpnrosifield { get; set; } = null!;

    public string OldbaggageAllowance { get; set; } = null!;

    public bool OldisApiwise { get; set; }

    public int Oldapiid { get; set; }

    public string OldairlineId { get; set; } = null!;

    public string OldflightAllowed { get; set; } = null!;

    public string OldflightNotAllowed { get; set; } = null!;

    public bool OldisCabinClassWise { get; set; }

    public string OldclassIds { get; set; } = null!;

    public bool OldisBookingClassWise { get; set; }

    public bool OldisBookingClassAllowed { get; set; }

    public string OldbookingClass { get; set; } = null!;

    public bool OldisFareBasisCodeWise { get; set; }

    public bool OldisFareBasisCodeAllowed { get; set; }

    public string OldfareBasisCode { get; set; } = null!;

    public bool OldisContinentWise { get; set; }

    public bool OldisSourceContinent { get; set; }

    public bool OldisAllowedSourceContinent { get; set; }

    public string OldsourceContinentIds { get; set; } = null!;

    public bool OldisDestinationContinent { get; set; }

    public bool OldisAllowedDestinationContinent { get; set; }

    public string OlddestinationContinentIds { get; set; } = null!;

    public bool OldisCountryWise { get; set; }

    public bool OldisStationWise { get; set; }

    public bool OldisValidFromStation { get; set; }

    public string OldvalidFromStationCode { get; set; } = null!;

    public bool OldisNotValidFromStation { get; set; }

    public string OldnotValidFromStationCode { get; set; } = null!;

    public bool OldisValidToStation { get; set; }

    public string OldvalidToStationCode { get; set; } = null!;

    public bool OldisNotValidToStation { get; set; }

    public string OldnotValidToStationCode { get; set; } = null!;

    public bool OldisSectorWise { get; set; }

    public bool OldisRoutingWise { get; set; }

    public bool OldisBookingDateWise { get; set; }

    public bool OldisDepartureDateWise { get; set; }

    public bool OldisAdvanceReservationWise { get; set; }

    public short OldadvanceReservationNoOfDays { get; set; }

    public bool OldisRoundTrip { get; set; }

    public bool OldisCircularTrip { get; set; }

    public bool OldisTotalStopOverWise { get; set; }

    public byte OldtotNoOfStopOverAllowed { get; set; }

    public decimal OldchargePerStopOver { get; set; }

    public bool OldisOutboundStopOverWise { get; set; }

    public byte OldtotNoOfOutboundStopOverAllowed { get; set; }

    public decimal OldoutboundChargePerStopOver { get; set; }

    public bool OldisInboundStopOverWise { get; set; }

    public byte OldtotNoOfInboundStopOverAllowed { get; set; }

    public decimal OldinboundChargePerStopOver { get; set; }

    public bool OldisMinimumStayWise { get; set; }

    public byte OldminStayNoOfDays { get; set; }

    public bool OldisMaximumStayWise { get; set; }

    public byte OldmaxStayNoOfDays { get; set; }

    public bool OldisTransferTransitWise { get; set; }

    public byte OldnoOfTransferTransitAllowed { get; set; }

    public bool OldisOpenJawWise { get; set; }

    public bool OldisSaleCountryWise { get; set; }

    public bool OldisCommTypePercentage { get; set; }

    public decimal OldcommissionAmt { get; set; }

    public bool OldisPlbonMileage { get; set; }

    public bool OldiataisPaxTotalFlightAmount { get; set; }

    public bool OldplbisPaxTotalFlightAmount { get; set; }

    public bool OldisActive { get; set; }

    public string NewcommCriteriaCode { get; set; } = null!;

    public string NewcommCriteriaDesc { get; set; } = null!;

    public bool NewisDomestic { get; set; }

    public bool NewisTourCodeWise { get; set; }

    public string NewtourCode { get; set; } = null!;

    public decimal Newcommission { get; set; }

    public string Newendorsement { get; set; } = null!;

    public string Newpnrosifield { get; set; } = null!;

    public string NewbaggageAllowance { get; set; } = null!;

    public bool NewisApiwise { get; set; }

    public int Newapiid { get; set; }

    public string NewairlineId { get; set; } = null!;

    public string NewflightAllowed { get; set; } = null!;

    public string NewflightNotAllowed { get; set; } = null!;

    public bool NewisCabinClassWise { get; set; }

    public string NewclassIds { get; set; } = null!;

    public bool NewisBookingClassWise { get; set; }

    public bool NewisBookingClassAllowed { get; set; }

    public string NewbookingClass { get; set; } = null!;

    public bool NewisFareBasisCodeWise { get; set; }

    public bool NewisFareBasisCodeAllowed { get; set; }

    public string NewfareBasisCode { get; set; } = null!;

    public bool NewisContinentWise { get; set; }

    public bool NewisSourceContinent { get; set; }

    public bool NewisAllowedSourceContinent { get; set; }

    public string NewsourceContinentIds { get; set; } = null!;

    public bool NewisDestinationContinent { get; set; }

    public bool NewisAllowedDestinationContinent { get; set; }

    public string NewdestinationContinentIds { get; set; } = null!;

    public bool NewisCountryWise { get; set; }

    public bool NewisStationWise { get; set; }

    public bool NewisValidFromStation { get; set; }

    public string NewvalidFromStationCode { get; set; } = null!;

    public bool NewisNotValidFromStation { get; set; }

    public string NewnotValidFromStationCode { get; set; } = null!;

    public bool NewisValidToStation { get; set; }

    public string NewvalidToStationCode { get; set; } = null!;

    public bool NewisNotValidToStation { get; set; }

    public string NewnotValidToStationCode { get; set; } = null!;

    public bool NewisSectorWise { get; set; }

    public bool NewisRoutingWise { get; set; }

    public bool NewisBookingDateWise { get; set; }

    public bool NewisDepartureDateWise { get; set; }

    public bool NewisAdvanceReservationWise { get; set; }

    public short NewadvanceReservationNoOfDays { get; set; }

    public bool NewisRoundTrip { get; set; }

    public bool NewisCircularTrip { get; set; }

    public bool NewisTotalStopOverWise { get; set; }

    public byte NewtotNoOfStopOverAllowed { get; set; }

    public decimal NewchargePerStopOver { get; set; }

    public bool NewisOutboundStopOverWise { get; set; }

    public byte NewtotNoOfOutboundStopOverAllowed { get; set; }

    public decimal NewoutboundChargePerStopOver { get; set; }

    public bool NewisInboundStopOverWise { get; set; }

    public byte NewtotNoOfInboundStopOverAllowed { get; set; }

    public decimal NewinboundChargePerStopOver { get; set; }

    public bool NewisMinimumStayWise { get; set; }

    public byte NewminStayNoOfDays { get; set; }

    public bool NewisMaximumStayWise { get; set; }

    public byte NewmaxStayNoOfDays { get; set; }

    public bool NewisTransferTransitWise { get; set; }

    public byte NewnoOfTransferTransitAllowed { get; set; }

    public bool NewisOpenJawWise { get; set; }

    public bool NewisSaleCountryWise { get; set; }

    public bool NewisCommTypePercentage { get; set; }

    public decimal NewcommissionAmt { get; set; }

    public bool NewisPlbonMileage { get; set; }

    public bool NewiataisPaxTotalFlightAmount { get; set; }

    public bool NewplbisPaxTotalFlightAmount { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
