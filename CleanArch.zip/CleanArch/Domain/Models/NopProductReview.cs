﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductReview
{
    public int ProductReviewId { get; set; }

    public int ProductId { get; set; }

    public int CustomerId { get; set; }

    public string Ipaddress { get; set; } = null!;

    public string Title { get; set; } = null!;

    public string ReviewText { get; set; } = null!;

    public int Rating { get; set; }

    public int HelpfulYesTotal { get; set; }

    public int HelpfulNoTotal { get; set; }

    public bool IsApproved { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;

    public virtual ICollection<NopProductReviewHelpfulness> NopProductReviewHelpfulnesses { get; set; } = new List<NopProductReviewHelpfulness>();

    public virtual NopProduct Product { get; set; } = null!;
}
