﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopTopicLocalized
{
    public int TopicLocalizedId { get; set; }

    public int TopicId { get; set; }

    public int LanguageId { get; set; }

    public string Title { get; set; } = null!;

    public string Body { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public string MetaTitle { get; set; } = null!;

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopTopic Topic { get; set; } = null!;
}
