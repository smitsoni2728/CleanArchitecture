﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCampaign
{
    public int CampaignId { get; set; }

    public string Name { get; set; } = null!;

    public string Subject { get; set; } = null!;

    public string Body { get; set; } = null!;

    public DateTime CreatedOn { get; set; }
}
