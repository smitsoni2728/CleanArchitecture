﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopBlogPost
{
    public int BlogPostId { get; set; }

    public int LanguageId { get; set; }

    public string BlogPostTitle { get; set; } = null!;

    public string BlogPostBody { get; set; } = null!;

    public bool BlogPostAllowComments { get; set; }

    public string Tags { get; set; } = null!;

    public int CreatedById { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopCustomer CreatedBy { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual ICollection<NopBlogComment> NopBlogComments { get; set; } = new List<NopBlogComment>();
}
