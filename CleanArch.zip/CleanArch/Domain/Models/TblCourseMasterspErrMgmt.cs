﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCourseMasterspErrMgmt
{
    public string Spname { get; set; } = null!;

    public int FrErrorNo { get; set; }

    public int ToErrorNo { get; set; }
}
