﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCustomerRoleProductPrice
{
    public int CustomerRoleProductPriceId { get; set; }

    public int CustomerRoleId { get; set; }

    public int ProductVariantId { get; set; }

    public decimal Price { get; set; }

    public virtual NopCustomerRole CustomerRole { get; set; } = null!;

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
