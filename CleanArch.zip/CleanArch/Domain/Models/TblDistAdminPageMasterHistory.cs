﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistAdminPageMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int PageId { get; set; }

    public int OldmenuId { get; set; }

    public string OldpageCaption { get; set; } = null!;

    public string OldpageUrl { get; set; } = null!;

    public bool OldbitMenuDefaultPage { get; set; }

    public bool OldisMaintenance { get; set; }

    public string OldmaintenanceMessage { get; set; } = null!;

    public int NewmenuId { get; set; }

    public string NewpageCaption { get; set; } = null!;

    public string NewpageUrl { get; set; } = null!;

    public bool NewbitMenuDefaultPage { get; set; }

    public bool NewisMaintenance { get; set; }

    public string NewmaintenanceMessage { get; set; } = null!;

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
