﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TableA
{
    public object? ColA { get; set; }

    public int? ColB { get; set; }
}
