﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCoucourierServiceProviderMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CourierServiceProviderId { get; set; }

    public string OldcourierServiceProviderCode { get; set; } = null!;

    public string OldcourierServiceProviderName { get; set; } = null!;

    public string Oldaddress1 { get; set; } = null!;

    public string Oldaddress2 { get; set; } = null!;

    public string Oldaddress3 { get; set; } = null!;

    public string Oldcountry { get; set; } = null!;

    public string Oldstate { get; set; } = null!;

    public string Oldcity { get; set; } = null!;

    public string OldpinCode { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewcourierServiceProviderCode { get; set; } = null!;

    public string NewcourierServiceProviderName { get; set; } = null!;

    public string Newaddress1 { get; set; } = null!;

    public string Newaddress2 { get; set; } = null!;

    public string Newaddress3 { get; set; } = null!;

    public string Newcountry { get; set; } = null!;

    public string Newstate { get; set; } = null!;

    public string Newcity { get; set; } = null!;

    public string NewpinCode { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
