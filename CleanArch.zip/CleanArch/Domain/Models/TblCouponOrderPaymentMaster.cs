﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponOrderPaymentMaster
{
    public int CouponOrderPaymentId { get; set; }

    public int CouponOrderReqId { get; set; }

    public decimal TotalAmount { get; set; }

    public bool IsPayment { get; set; }

    public string CreatedDate { get; set; } = null!;

    public string CreatedIp { get; set; } = null!;
}
