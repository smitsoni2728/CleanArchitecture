﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class T11
{
    public string? C1 { get; set; }

    public string? C2 { get; set; }
}
