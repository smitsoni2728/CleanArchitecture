﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircustomerGroupTypeMasterCommand
{
    public byte CommandId { get; set; }

    public string CommandType { get; set; } = null!;

    public string CommandDesc { get; set; } = null!;

    public string CommandProc { get; set; } = null!;
}
