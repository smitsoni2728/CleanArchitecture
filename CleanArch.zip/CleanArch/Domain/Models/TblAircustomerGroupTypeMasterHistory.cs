﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircustomerGroupTypeMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CustomerGroupTypeId { get; set; }

    public string OldcustomerGroupTypeName { get; set; } = null!;

    public bool OldisSendGreetingBySms { get; set; }

    public bool OldisSendGreetingByEmail { get; set; }

    public bool OldisActive { get; set; }

    public string NewcustomerGroupTypeName { get; set; } = null!;

    public bool NewisSendGreetingBySms { get; set; }

    public bool NewisSendGreetingByEmail { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
