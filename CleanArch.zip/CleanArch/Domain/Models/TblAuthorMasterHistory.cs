﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAuthorMasterHistory
{
    public int HistoryId { get; set; }

    public int CommandId { get; set; }

    public int AuthorId { get; set; }

    public string OldauthorName { get; set; } = null!;

    public string Oldcountry { get; set; } = null!;

    public string OldbookName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewauthorName { get; set; } = null!;

    public string Newcountry { get; set; } = null!;

    public string NewbookName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
