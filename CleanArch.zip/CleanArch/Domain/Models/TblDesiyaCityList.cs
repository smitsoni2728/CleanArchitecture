﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaCityList
{
    public string? City { get; set; }

    public string? F2 { get; set; }

    public string? StateName { get; set; }
}
