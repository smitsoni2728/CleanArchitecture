﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBookTypeMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int BookTypeId { get; set; }

    public string OldbookTypeCode { get; set; } = null!;

    public string OldbookTypeName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewbookTypeCode { get; set; } = null!;

    public string NewbookTypeName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
