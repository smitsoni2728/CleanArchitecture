﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopForumsPrivateMessage
{
    public int PrivateMessageId { get; set; }

    public int FromUserId { get; set; }

    public int ToUserId { get; set; }

    public string Subject { get; set; } = null!;

    public string Text { get; set; } = null!;

    public bool IsRead { get; set; }

    public bool IsDeletedByAuthor { get; set; }

    public bool IsDeletedByRecipient { get; set; }

    public DateTime CreatedOn { get; set; }
}
