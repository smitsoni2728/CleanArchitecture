﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDhavanHist
{
    public int HistoryId { get; set; }

    public byte? OldEntryId { get; set; }

    public DateTime? OldEntryDate { get; set; }

    public byte? NewEntryId { get; set; }

    public DateTime? NewEntryDate { get; set; }

    public string? EntryType { get; set; }

    public string? EntryZone { get; set; }
}
