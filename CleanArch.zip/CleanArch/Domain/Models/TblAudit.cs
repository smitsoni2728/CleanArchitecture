﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAudit
{
    public int AuditId { get; set; }

    public DateTime AuditDate { get; set; }

    public int RefId { get; set; }
}
