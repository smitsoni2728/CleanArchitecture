﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorMaster
{
    public int DistributorId { get; set; }

    public byte TypeDetId { get; set; }

    public string Name { get; set; } = null!;

    public string DistributorCode { get; set; } = null!;

    public string CmpName { get; set; } = null!;

    public string Add1 { get; set; } = null!;

    public string Add2 { get; set; } = null!;

    public string Add3 { get; set; } = null!;

    public string City { get; set; } = null!;

    public string State { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string Pincode { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string Mobile { get; set; } = null!;

    public string Fax { get; set; } = null!;

    public string Pan { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string TranPwd { get; set; } = null!;

    public DateTime DateOfBirth { get; set; }

    public byte DistributorLevel { get; set; }

    public int Level1DistributorId { get; set; }

    public int Level2DistributorId { get; set; }

    public DateTime JoiningDate { get; set; }

    public string Padd1 { get; set; } = null!;

    public string Padd2 { get; set; } = null!;

    public string Padd3 { get; set; } = null!;

    public string Pcity { get; set; } = null!;

    public string Pstate { get; set; } = null!;

    public string Pcountry { get; set; } = null!;

    public string Ppincode { get; set; } = null!;

    public string Pphone { get; set; } = null!;

    public string Pmobile { get; set; } = null!;

    public string Pfax { get; set; } = null!;

    public bool IsCustomer { get; set; }

    public bool IsActive { get; set; }

    public string ActivationRemark { get; set; } = null!;

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public bool IsIrctcagent { get; set; }

    public bool IsIrctcagentActive { get; set; }

    public string Gender { get; set; } = null!;

    public int CardId { get; set; }

    public bool IsPaid { get; set; }

    public string Cad { get; set; } = null!;

    public string IrctcuserId { get; set; } = null!;

    public bool? IsProfileUpdated { get; set; }

    public string EmpCode { get; set; } = null!;

    public int InvoiceNo { get; set; }

    public DateTime PaidDateTime { get; set; }

    public decimal PaidAmount { get; set; }

    public bool IsForm60 { get; set; }

    public decimal RegistrationAmount { get; set; }

    public bool IsBoardDispatched { get; set; }

    public bool IsWelcomeKitDispatched { get; set; }

    public int EmpId { get; set; }

    public int MaintenanceChargeDetId { get; set; }

    public bool IsGenerateComm { get; set; }

    public bool IsTranPwdUpdated { get; set; }

    public bool IsTranAllowed { get; set; }

    public string TranAllowedRemark { get; set; } = null!;

    public string MaritalStatus { get; set; } = null!;

    public string Occupation { get; set; } = null!;

    public bool IsPnremailAlerts { get; set; }

    public bool IsPnrsmsalerts { get; set; }

    public DateTime ActivationDate { get; set; }

    public bool IsTrial { get; set; }

    public DateTime TrialStartDate { get; set; }

    public DateTime TrialUpgradationDate { get; set; }

    public string UpgradationRemark { get; set; } = null!;

    public bool IsEmailSmssent { get; set; }

    public bool IsFirstLogin { get; set; }

    public int NoOfUnreadMsgs { get; set; }

    public bool IsShowNetAmount { get; set; }

    public bool IsTransactionFee { get; set; }

    public bool IsSearchOnSpecialFare { get; set; }

    public bool IsAgent { get; set; }

    public int ApioperatorLinkId { get; set; }

    public int Level1ReferredByDistributorId { get; set; }

    public int CardCityId { get; set; }

    public decimal TransactionCredit { get; set; }

    public int RequestId { get; set; }

    public int Level2ReferredByDistributorId { get; set; }

    public int Level3ReferredByDistributorId { get; set; }

    public int Level4ReferredByDistributorId { get; set; }

    public int Level5ReferredByDistributorId { get; set; }

    public int Level6ReferredByDistributorId { get; set; }

    public int Level7ReferredByDistributorId { get; set; }

    public string LogoImageUrl { get; set; } = null!;

    public bool IsLogoDisplay { get; set; }

    public int DistributorGroupDealId { get; set; }

    public int DistributorGroupGdsid { get; set; }

    public int MasterDistributorId { get; set; }

    public int UserSeqNo { get; set; }

    public string LoginName { get; set; } = null!;

    public string Pwd { get; set; } = null!;

    public bool IsAirallowBookingMarkup { get; set; }

    public bool IsAllowLimitAllocationToDownline { get; set; }

    public string AlternateEmail { get; set; } = null!;

    public string OfficeSpace { get; set; } = null!;

    public string BusinessType { get; set; } = null!;

    public bool IsIataagent { get; set; }

    public string YearInBusiness { get; set; } = null!;

    public string PandocImg { get; set; } = null!;

    public string EduQualification { get; set; } = null!;

    public string UserRemark { get; set; } = null!;

    public bool IsSendBalanceReminder { get; set; }

    public decimal ReminderBalance { get; set; }

    public decimal ReminderInterval { get; set; }

    public bool IsSendReminderEmail { get; set; }

    public bool IsSendReminderSms { get; set; }

    public bool IsSerTaxOnSerCharge { get; set; }

    public bool IsAllowToAddDownline { get; set; }

    public string PartnerName1 { get; set; } = null!;

    public string PartnerAge1 { get; set; } = null!;

    public string PartnerOtherBusiness1 { get; set; } = null!;

    public string PartnerName2 { get; set; } = null!;

    public string PartnerAge2 { get; set; } = null!;

    public string PartnerOtherBusiness2 { get; set; } = null!;

    public string ReferenceDet1 { get; set; } = null!;

    public string ReferenceDet2 { get; set; } = null!;

    public string NameOfBank { get; set; } = null!;

    public string BankAccountNo { get; set; } = null!;

    public string BankBranch { get; set; } = null!;

    public string BenameOfOrg1 { get; set; } = null!;

    public string BenatureOfBusiness1 { get; set; } = null!;

    public decimal BeturnOverRs1 { get; set; }

    public short BeyearFrom1 { get; set; }

    public short BeyearTo1 { get; set; }

    public string BeproductLine1 { get; set; } = null!;

    public string BenoOfEmp1 { get; set; } = null!;

    public string BenameOfOrg2 { get; set; } = null!;

    public string BenatureOfBusiness2 { get; set; } = null!;

    public decimal BeturnOverRs2 { get; set; }

    public short BeyearFrom2 { get; set; }

    public short BeyearTo2 { get; set; }

    public string BeproductLine2 { get; set; } = null!;

    public string BenoOfEmp2 { get; set; } = null!;

    public bool IsAllowCouponSearch { get; set; }

    public bool IsTranPwdMendate { get; set; }

    public string Ccode { get; set; } = null!;

    public bool IsCcdifferentForLcciata { get; set; }

    public int DistributorGroupInsuranceId { get; set; }

    public int DistributorGroupForexId { get; set; }

    public int DistributorGroupDealIdint { get; set; }

    public bool IsEmailTicketWithoutFare { get; set; }
}
