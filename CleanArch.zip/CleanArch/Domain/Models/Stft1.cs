﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Stft1
{
    public int? T1 { get; set; }
}
