﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class DboTemptable
{
    public string? Id { get; set; }

    public string? Title { get; set; }
}
