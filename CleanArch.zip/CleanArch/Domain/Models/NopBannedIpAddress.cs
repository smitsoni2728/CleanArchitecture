﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopBannedIpAddress
{
    public int BannedIpAddressId { get; set; }

    public string Address { get; set; } = null!;

    public string? Comment { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }
}
