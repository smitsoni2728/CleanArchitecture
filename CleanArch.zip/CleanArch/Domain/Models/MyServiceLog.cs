﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class MyServiceLog
{
    public int InLogId { get; set; }

    public string VcStatus { get; set; } = null!;

    public DateTime DtCreated { get; set; }
}
