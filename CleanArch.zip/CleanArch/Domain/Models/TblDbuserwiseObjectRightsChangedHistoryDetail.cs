﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDbuserwiseObjectRightsChangedHistoryDetail
{
    public int HistoryDetId { get; set; }

    public int HistoryId { get; set; }

    public string ObjectName { get; set; } = null!;
}
