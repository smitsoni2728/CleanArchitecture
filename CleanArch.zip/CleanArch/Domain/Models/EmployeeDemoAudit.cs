﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmployeeDemoAudit
{
    public int? EmpId { get; set; }

    public string? EmpName { get; set; }

    public decimal? EmpSal { get; set; }

    public string? AuditAction { get; set; }

    public DateTime? AuditTimestamp { get; set; }
}
