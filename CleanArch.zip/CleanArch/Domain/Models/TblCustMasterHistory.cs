﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCustMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CustId { get; set; }

    public string OldcustName { get; set; } = null!;

    public string OldcustCity { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewcustName { get; set; } = null!;

    public string NewcustCity { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
