﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCityMstHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CityId { get; set; }

    public string OldcityCode { get; set; } = null!;

    public string OldcityName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string Oldremark { get; set; } = null!;

    public string NewcityCode { get; set; } = null!;

    public string NewcityName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public string Newremark { get; set; } = null!;

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
