﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmployeeDemo
{
    public int EmpId { get; set; }

    public string? EmpName { get; set; }

    public decimal? EmpSal { get; set; }
}
