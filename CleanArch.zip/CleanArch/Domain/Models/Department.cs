﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Department
{
    public int Id { get; set; }

    public string? Departmentname { get; set; }
}
