﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopBlogComment
{
    public int BlogCommentId { get; set; }

    public int BlogPostId { get; set; }

    public int CustomerId { get; set; }

    public string Ipaddress { get; set; } = null!;

    public string CommentText { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public virtual NopBlogPost BlogPost { get; set; } = null!;
}
