﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Customer
{
    public int ProductId { get; set; }

    public string? CusName { get; set; }

    public string? CusMobile { get; set; }
}
