﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaRoomDescription
{
    public string? VendorId { get; set; }

    public string? RoomType { get; set; }

    public string? RoomTypeId { get; set; }

    public string? RoomDescription { get; set; }

    public string? MaxAdultOccupancy { get; set; }

    public string? MaxChildOccupancy { get; set; }

    public string? MaxInfantOccupancy { get; set; }

    public string? MaxGuestOccupancy { get; set; }

    public string? ImagePath { get; set; }
}
