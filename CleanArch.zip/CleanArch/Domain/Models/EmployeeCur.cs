﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmployeeCur
{
    public int EmpId { get; set; }

    public string EmpName { get; set; } = null!;

    public int Salary { get; set; }

    public string Address { get; set; } = null!;
}
