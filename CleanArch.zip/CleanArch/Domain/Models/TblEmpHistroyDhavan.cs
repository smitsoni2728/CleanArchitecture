﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmpHistroyDhavan
{
    public int HistoryId { get; set; }

    public int CommandId { get; set; }

    public int Id { get; set; }

    public int OldUserTypeCode { get; set; }

    public string OldUserTypeName { get; set; } = null!;

    public bool OldIsActive { get; set; }

    public int NewUserTypeCode { get; set; }

    public string NewUserTypeName { get; set; } = null!;

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
