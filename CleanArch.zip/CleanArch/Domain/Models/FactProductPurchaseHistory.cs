﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class FactProductPurchaseHistory
{
    public int? ProductId { get; set; }

    public DateTime? LastPurchaseDate { get; set; }

    public int? TotalQuantity { get; set; }
}
