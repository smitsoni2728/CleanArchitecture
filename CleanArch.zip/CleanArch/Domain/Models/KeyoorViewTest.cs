﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class KeyoorViewTest
{
    public int SrNo { get; set; }

    public DateTime DtDateTime { get; set; }
}
