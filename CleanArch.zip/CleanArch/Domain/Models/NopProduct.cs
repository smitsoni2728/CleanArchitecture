﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProduct
{
    public int ProductId { get; set; }

    public string Name { get; set; } = null!;

    public string ShortDescription { get; set; } = null!;

    public string FullDescription { get; set; } = null!;

    public string AdminComment { get; set; } = null!;

    public int TemplateId { get; set; }

    public bool ShowOnHomePage { get; set; }

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public string MetaTitle { get; set; } = null!;

    public string Sename { get; set; } = null!;

    public bool AllowCustomerReviews { get; set; }

    public bool? AllowCustomerRatings { get; set; }

    public int RatingSum { get; set; }

    public int TotalRatingVotes { get; set; }

    public bool Published { get; set; }

    public bool Deleted { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopCrossSellProduct> NopCrossSellProducts { get; set; } = new List<NopCrossSellProduct>();

    public virtual ICollection<NopProductCategoryMapping> NopProductCategoryMappings { get; set; } = new List<NopProductCategoryMapping>();

    public virtual ICollection<NopProductLocalized> NopProductLocalizeds { get; set; } = new List<NopProductLocalized>();

    public virtual ICollection<NopProductManufacturerMapping> NopProductManufacturerMappings { get; set; } = new List<NopProductManufacturerMapping>();

    public virtual ICollection<NopProductPicture> NopProductPictures { get; set; } = new List<NopProductPicture>();

    public virtual ICollection<NopProductRating> NopProductRatings { get; set; } = new List<NopProductRating>();

    public virtual ICollection<NopProductReview> NopProductReviews { get; set; } = new List<NopProductReview>();

    public virtual ICollection<NopProductSpecificationAttributeMapping> NopProductSpecificationAttributeMappings { get; set; } = new List<NopProductSpecificationAttributeMapping>();

    public virtual ICollection<NopProductVariant> NopProductVariants { get; set; } = new List<NopProductVariant>();

    public virtual ICollection<NopRelatedProduct> NopRelatedProducts { get; set; } = new List<NopRelatedProduct>();

    public virtual NopProductTemplate Template { get; set; } = null!;

    public virtual ICollection<NopProductTag> ProductTags { get; set; } = new List<NopProductTag>();
}
