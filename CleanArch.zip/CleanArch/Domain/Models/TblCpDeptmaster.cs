﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCpDeptmaster
{
    public int? Iempid { get; set; }

    public int? Ideptid { get; set; }
}
