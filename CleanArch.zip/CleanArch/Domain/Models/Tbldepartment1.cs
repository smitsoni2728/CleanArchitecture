﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tbldepartment1
{
    public int Deptid { get; set; }

    public string Deptname { get; set; } = null!;
}
