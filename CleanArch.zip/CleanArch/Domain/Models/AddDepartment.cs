﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AddDepartment
{
    public int DeptId { get; set; }

    public string DeptName { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateTime? CreateDate { get; set; }

    public DateTime? UpdateDate { get; set; }
}
