﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponOrderRequestMaster
{
    public int CouponOrderReqId { get; set; }

    public int CouponDetId { get; set; }

    public int VendorId { get; set; }

    public int TotalCoupon { get; set; }

    public string Status { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;
}
