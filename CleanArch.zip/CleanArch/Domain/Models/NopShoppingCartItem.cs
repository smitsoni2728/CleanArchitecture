﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopShoppingCartItem
{
    public int ShoppingCartItemId { get; set; }

    public int ShoppingCartTypeId { get; set; }

    public Guid CustomerSessionGuid { get; set; }

    public int ProductVariantId { get; set; }

    public string AttributesXml { get; set; } = null!;

    public decimal CustomerEnteredPrice { get; set; }

    public int Quantity { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopCustomerSession CustomerSession { get; set; } = null!;

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
