﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Sale
{
    public string? Month { get; set; }

    public int? SaleAmount { get; set; }

    public int? Id { get; set; }

    public string? Product { get; set; }
}
