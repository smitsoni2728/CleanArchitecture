﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Error
{
    public int ErrorId { get; set; }

    public string ErrorDescr { get; set; } = null!;

    public int? ErrorFlag { get; set; }
}
