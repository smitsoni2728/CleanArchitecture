﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaInAndAround
{
    public string? VendorId { get; set; }

    public string? NameOfAttraction { get; set; }

    public string? DistanceInKm { get; set; }
}
