﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDummyMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int DummyId { get; set; }

    public int OlddummyMasterId { get; set; }

    public string OlddummyName { get; set; } = null!;

    public string OlddummySurname { get; set; } = null!;

    public string OlddummyRole { get; set; } = null!;

    public bool OldisActive { get; set; }

    public int NewdummyMasterId { get; set; }

    public string NewdummyName { get; set; } = null!;

    public string NewdummySurname { get; set; } = null!;

    public string NewdummyRole { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
