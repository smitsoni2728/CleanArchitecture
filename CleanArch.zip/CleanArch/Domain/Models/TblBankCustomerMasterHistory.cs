﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBankCustomerMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CustId { get; set; }

    public int OldbankId { get; set; }

    public int OldbranchId { get; set; }

    public string OldaccNo { get; set; } = null!;

    public string OldcustName { get; set; } = null!;

    public string Oldaddress { get; set; } = null!;

    public string Oldcity { get; set; } = null!;

    public string OldcontactNo { get; set; } = null!;

    public string Oldemail { get; set; } = null!;

    public bool OldisActive { get; set; }

    public int NewbankId { get; set; }

    public int NewbranchId { get; set; }

    public string NewaccNo { get; set; } = null!;

    public string NewcustName { get; set; } = null!;

    public string Newaddress { get; set; } = null!;

    public string Newcity { get; set; } = null!;

    public string NewcontactNo { get; set; } = null!;

    public string Newemail { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
