﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorMasterAto
{
    public int DistributorId { get; set; }

    public string DistributorCode { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string MiddleName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public string MaritalStatus { get; set; } = null!;

    public DateTime BirthDate { get; set; }

    public string Occupation { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string ResidAddressLine1 { get; set; } = null!;

    public string ResidAddressLine2 { get; set; } = null!;

    public string ResidAddressLine3 { get; set; } = null!;

    public string ResidCity { get; set; } = null!;

    public string ResidState { get; set; } = null!;

    public string ResidCountry { get; set; } = null!;

    public string ResidPinCode { get; set; } = null!;

    public string ResidPhoneNo { get; set; } = null!;

    public string CompName { get; set; } = null!;

    public string OfficeAddressLine1 { get; set; } = null!;

    public string OfficeAddressLine2 { get; set; } = null!;

    public string OfficeAddressLine3 { get; set; } = null!;

    public string OfficeCity { get; set; } = null!;

    public string OfficeState { get; set; } = null!;

    public string OfficeCountry { get; set; } = null!;

    public string OfficePinCode { get; set; } = null!;

    public string OfficePhoneNo { get; set; } = null!;

    public string OfficeFax { get; set; } = null!;

    public string MobileNo { get; set; } = null!;

    public string Panno { get; set; } = null!;

    public bool IsCustomer { get; set; }

    public bool IsPnremailAlerts { get; set; }

    public bool IsPnrsmsalerts { get; set; }

    public string UserName { get; set; } = null!;

    public string Pwd { get; set; } = null!;

    public DateTime JoiningDate { get; set; }

    public DateTime ActivationDate { get; set; }

    public bool IsActive { get; set; }

    public bool IsTrial { get; set; }

    public DateTime TrialStartDate { get; set; }

    public DateTime TrialUpgradationDate { get; set; }

    public string UpgradationRemark { get; set; } = null!;

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdatedBy { get; set; }

    public DateTime UpdatedDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public bool IsEmailSmssent { get; set; }

    public bool IsFirstLogin { get; set; }

    public bool IsForm60 { get; set; }
}
