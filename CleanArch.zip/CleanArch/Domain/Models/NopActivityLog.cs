﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopActivityLog
{
    public int ActivityLogId { get; set; }

    public int ActivityLogTypeId { get; set; }

    public int CustomerId { get; set; }

    public string Comment { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public virtual NopActivityLogType ActivityLogType { get; set; } = null!;

    public virtual NopCustomer Customer { get; set; } = null!;
}
