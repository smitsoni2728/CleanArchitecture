﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmp1
{
    public int Iempid { get; set; }

    public string? Cempname { get; set; }

    public string? Cempdept { get; set; }
}
