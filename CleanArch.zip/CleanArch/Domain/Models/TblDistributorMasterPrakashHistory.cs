﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorMasterPrakashHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int DistributorId { get; set; }

    public string OlddistributorName { get; set; } = null!;

    public string Oldaddress1 { get; set; } = null!;

    public string Oldaddress2 { get; set; } = null!;

    public string Oldaddress3 { get; set; } = null!;

    public string Oldcity { get; set; } = null!;

    public string Oldstate { get; set; } = null!;

    public string Oldcountry { get; set; } = null!;

    public string OldpinCode { get; set; } = null!;

    public string Oldphone { get; set; } = null!;

    public string OldmobileNo { get; set; } = null!;

    public string OldemailId { get; set; } = null!;

    public DateTime OldjoiningDate { get; set; }

    public decimal OldopeningBalance { get; set; }

    public decimal OldopeningQty { get; set; }

    public bool OldisActive { get; set; }

    public string NewdistributorName { get; set; } = null!;

    public string Newaddress1 { get; set; } = null!;

    public string Newaddress2 { get; set; } = null!;

    public string Newaddress3 { get; set; } = null!;

    public string Newcity { get; set; } = null!;

    public string Newstate { get; set; } = null!;

    public string Newcountry { get; set; } = null!;

    public string NewpinCode { get; set; } = null!;

    public string Newphone { get; set; } = null!;

    public string NewmobileNo { get; set; } = null!;

    public string NewemailId { get; set; } = null!;

    public DateTime NewjoiningDate { get; set; }

    public decimal NewopeningBalance { get; set; }

    public decimal NewopeningQty { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
