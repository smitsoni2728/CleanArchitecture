﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopSearchLog
{
    public int SearchLogId { get; set; }

    public string SearchTerm { get; set; } = null!;

    public int CustomerId { get; set; }

    public DateTime CreatedOn { get; set; }
}
