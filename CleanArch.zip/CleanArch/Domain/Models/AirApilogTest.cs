﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AirApilogTest
{
    public int AirApilogId { get; set; }

    public string LogName { get; set; } = null!;

    public string? RequestLog { get; set; }

    public string? ResponseLog { get; set; }

    public string? RequestTimestamp { get; set; }

    public string? ResponseTimestamp { get; set; }

    public string? LastUpdateOn { get; set; }
}
