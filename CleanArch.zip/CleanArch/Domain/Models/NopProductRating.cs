﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductRating
{
    public int ProductRatingId { get; set; }

    public int ProductId { get; set; }

    public int CustomerId { get; set; }

    public int Rating { get; set; }

    public DateTime RatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;

    public virtual NopProduct Product { get; set; } = null!;
}
