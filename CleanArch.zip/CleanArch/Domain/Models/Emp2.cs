﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Emp2
{
    public int EmpId { get; set; }

    public string UserId { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string MaritalStatus { get; set; } = null!;

    public string Gender { get; set; } = null!;
}
