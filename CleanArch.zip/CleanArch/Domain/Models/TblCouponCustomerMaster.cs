﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponCustomerMaster
{
    public int CustomerId { get; set; }

    public int VendorId { get; set; }

    public string CustomerName { get; set; } = null!;

    public string MobileNo { get; set; } = null!;

    public string EmailId { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
