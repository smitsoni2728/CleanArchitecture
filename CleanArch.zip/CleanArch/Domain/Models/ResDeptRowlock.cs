﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResDeptRowlock
{
    public int? Ideptid { get; set; }
}
