﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopSmsprovider
{
    public int SmsproviderId { get; set; }

    public string Name { get; set; } = null!;

    public string ClassName { get; set; } = null!;

    public string SystemKeyword { get; set; } = null!;

    public bool IsActive { get; set; }
}
