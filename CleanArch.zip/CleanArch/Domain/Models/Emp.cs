﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Emp
{
    public int EmpId { get; set; }

    public string Ssnnumber { get; set; } = null!;

    public string? UserId { get; set; }

    public DateTime BirthDate { get; set; }

    public DateTime HireDate { get; set; }

    public string MaritalStatus { get; set; } = null!;

    public string Gender { get; set; } = null!;
}
