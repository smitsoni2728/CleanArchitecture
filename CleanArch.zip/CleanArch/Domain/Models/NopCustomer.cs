﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCustomer
{
    public int CustomerId { get; set; }

    public Guid CustomerGuid { get; set; }

    public string Email { get; set; } = null!;

    public string Username { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public string SaltKey { get; set; } = null!;

    public int AffiliateId { get; set; }

    public int BillingAddressId { get; set; }

    public int ShippingAddressId { get; set; }

    public int LastPaymentMethodId { get; set; }

    public string LastAppliedCouponCode { get; set; } = null!;

    public string GiftCardCouponCodes { get; set; } = null!;

    public string CheckoutAttributes { get; set; } = null!;

    public int LanguageId { get; set; }

    public int CurrencyId { get; set; }

    public int TaxDisplayTypeId { get; set; }

    public bool IsTaxExempt { get; set; }

    public bool IsAdmin { get; set; }

    public bool IsGuest { get; set; }

    public bool IsForumModerator { get; set; }

    public int TotalForumPosts { get; set; }

    public string Signature { get; set; } = null!;

    public string AdminComment { get; set; } = null!;

    public bool? Active { get; set; }

    public bool Deleted { get; set; }

    public DateTime RegistrationDate { get; set; }

    public string TimeZoneId { get; set; } = null!;

    public int AvatarId { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public virtual ICollection<NopActivityLog> NopActivityLogs { get; set; } = new List<NopActivityLog>();

    public virtual ICollection<NopAddress> NopAddresses { get; set; } = new List<NopAddress>();

    public virtual ICollection<NopBlogPost> NopBlogPosts { get; set; } = new List<NopBlogPost>();

    public virtual ICollection<NopCustomerAttribute> NopCustomerAttributes { get; set; } = new List<NopCustomerAttribute>();

    public virtual ICollection<NopDiscountUsageHistory> NopDiscountUsageHistories { get; set; } = new List<NopDiscountUsageHistory>();

    public virtual ICollection<NopGiftCardUsageHistory> NopGiftCardUsageHistories { get; set; } = new List<NopGiftCardUsageHistory>();

    public virtual ICollection<NopPollVotingRecord> NopPollVotingRecords { get; set; } = new List<NopPollVotingRecord>();

    public virtual ICollection<NopProductRating> NopProductRatings { get; set; } = new List<NopProductRating>();

    public virtual ICollection<NopProductReview> NopProductReviews { get; set; } = new List<NopProductReview>();

    public virtual ICollection<NopReturnRequest> NopReturnRequests { get; set; } = new List<NopReturnRequest>();

    public virtual ICollection<NopRewardPointsHistory> NopRewardPointsHistories { get; set; } = new List<NopRewardPointsHistory>();

    public virtual ICollection<NopCustomerRole> CustomerRoles { get; set; } = new List<NopCustomerRole>();
}
