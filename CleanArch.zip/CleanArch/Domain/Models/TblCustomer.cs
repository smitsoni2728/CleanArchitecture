﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCustomer
{
    public int CustomerId { get; set; }

    public string Name { get; set; } = null!;
}
