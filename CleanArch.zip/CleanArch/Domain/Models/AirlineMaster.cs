﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AirlineMaster
{
    public int Airlineid { get; set; }

    public string AirlineCode { get; set; } = null!;

    public string AirlineName { get; set; } = null!;
}
