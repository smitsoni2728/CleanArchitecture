﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDdltest
{
    public int TestId { get; set; }

    public string? TestName { get; set; }

    public string? TestDesc { get; set; }

    public string? TestLast { get; set; }
}
