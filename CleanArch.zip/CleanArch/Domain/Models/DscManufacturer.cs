﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class DscManufacturer
{
    public int ManufacturerId { get; set; }

    public string Name { get; set; } = null!;

    public int? ImageId { get; set; }

    public string? Url { get; set; }

    public virtual ICollection<DscCategoryManufacturerCount> DscCategoryManufacturerCounts { get; set; } = new List<DscCategoryManufacturerCount>();

    public virtual DscImage? Image { get; set; }
}
