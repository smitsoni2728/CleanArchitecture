﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariant
{
    public int ProductVariantId { get; set; }

    public int ProductId { get; set; }

    public string Name { get; set; } = null!;

    public string Sku { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string AdminComment { get; set; } = null!;

    public string ManufacturerPartNumber { get; set; } = null!;

    public bool IsGiftCard { get; set; }

    public int GiftCardType { get; set; }

    public bool IsDownload { get; set; }

    public int DownloadId { get; set; }

    public bool? UnlimitedDownloads { get; set; }

    public int MaxNumberOfDownloads { get; set; }

    public int? DownloadExpirationDays { get; set; }

    public int DownloadActivationType { get; set; }

    public bool HasSampleDownload { get; set; }

    public int SampleDownloadId { get; set; }

    public bool HasUserAgreement { get; set; }

    public string UserAgreementText { get; set; } = null!;

    public bool IsRecurring { get; set; }

    public int CycleLength { get; set; }

    public int CyclePeriod { get; set; }

    public int TotalCycles { get; set; }

    public bool IsShipEnabled { get; set; }

    public bool IsFreeShipping { get; set; }

    public decimal AdditionalShippingCharge { get; set; }

    public bool IsTaxExempt { get; set; }

    public int TaxCategoryId { get; set; }

    public int ManageInventory { get; set; }

    public int StockQuantity { get; set; }

    public bool? DisplayStockAvailability { get; set; }

    public bool DisplayStockQuantity { get; set; }

    public int MinStockQuantity { get; set; }

    public int LowStockActivityId { get; set; }

    public int NotifyAdminForQuantityBelow { get; set; }

    public int Backorders { get; set; }

    public int OrderMinimumQuantity { get; set; }

    public int OrderMaximumQuantity { get; set; }

    public int WarehouseId { get; set; }

    public bool DisableBuyButton { get; set; }

    public bool CallForPrice { get; set; }

    public decimal Price { get; set; }

    public decimal OldPrice { get; set; }

    public decimal ProductCost { get; set; }

    public bool CustomerEntersPrice { get; set; }

    public decimal MinimumCustomerEnteredPrice { get; set; }

    public decimal MaximumCustomerEnteredPrice { get; set; }

    public decimal Weight { get; set; }

    public decimal Length { get; set; }

    public decimal Width { get; set; }

    public decimal Height { get; set; }

    public int PictureId { get; set; }

    public DateTime? AvailableStartDateTime { get; set; }

    public DateTime? AvailableEndDateTime { get; set; }

    public bool Published { get; set; }

    public bool Deleted { get; set; }

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopCustomerRoleProductPrice> NopCustomerRoleProductPrices { get; set; } = new List<NopCustomerRoleProductPrice>();

    public virtual ICollection<NopOrderProductVariant> NopOrderProductVariants { get; set; } = new List<NopOrderProductVariant>();

    public virtual ICollection<NopProductVariantAttributeCombination> NopProductVariantAttributeCombinations { get; set; } = new List<NopProductVariantAttributeCombination>();

    public virtual ICollection<NopProductVariantLocalized> NopProductVariantLocalizeds { get; set; } = new List<NopProductVariantLocalized>();

    public virtual ICollection<NopProductVariantPricelistMapping> NopProductVariantPricelistMappings { get; set; } = new List<NopProductVariantPricelistMapping>();

    public virtual ICollection<NopProductVariantProductAttributeMapping> NopProductVariantProductAttributeMappings { get; set; } = new List<NopProductVariantProductAttributeMapping>();

    public virtual ICollection<NopShoppingCartItem> NopShoppingCartItems { get; set; } = new List<NopShoppingCartItem>();

    public virtual ICollection<NopTierPrice> NopTierPrices { get; set; } = new List<NopTierPrice>();

    public virtual NopProduct Product { get; set; } = null!;

    public virtual ICollection<NopDiscount> Discounts { get; set; } = new List<NopDiscount>();

    public virtual ICollection<NopDiscount> DiscountsNavigation { get; set; } = new List<NopDiscount>();
}
