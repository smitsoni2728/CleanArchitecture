﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopForumsForum
{
    public int ForumId { get; set; }

    public int ForumGroupId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public int NumTopics { get; set; }

    public int NumPosts { get; set; }

    public int LastTopicId { get; set; }

    public int LastPostId { get; set; }

    public int LastPostUserId { get; set; }

    public DateTime? LastPostTime { get; set; }

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopForumsGroup ForumGroup { get; set; } = null!;

    public virtual ICollection<NopForumsTopic> NopForumsTopics { get; set; } = new List<NopForumsTopic>();
}
