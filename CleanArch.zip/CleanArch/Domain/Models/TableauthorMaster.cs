﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TableauthorMaster
{
    public int AuthorId { get; set; }

    public string? AuthorName { get; set; }

    public string? Country { get; set; }

    public string? BookName { get; set; }

    public bool? IsActive { get; set; }

    public byte? CommandId { get; set; }

    public int? CreateBy { get; set; }

    public DateTime? CreateDate { get; set; }

    public string? CreateIp { get; set; }

    public int? UpdateBy { get; set; }

    public DateTime? UpdateDate { get; set; }

    public string? UpdateIp { get; set; }
}
