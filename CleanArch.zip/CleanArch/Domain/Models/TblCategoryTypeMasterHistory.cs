﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCategoryTypeMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CategoryTypeId { get; set; }

    public string OldcategoryTypeCode { get; set; } = null!;

    public string OldcategoryTypeName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewcategoryTypeCode { get; set; } = null!;

    public string NewcategoryTypeName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
