﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDepartmentMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int DepartmentId { get; set; }

    public int OlddepartmentTypeId { get; set; }

    public string OlddepartmentCode { get; set; } = null!;

    public string OlddepartmentName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public int NewdepartmentTypeId { get; set; }

    public string NewdepartmentCode { get; set; } = null!;

    public string NewdepartmentName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
