﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductAttribute
{
    public int ProductAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public virtual ICollection<NopProductAttributeLocalized> NopProductAttributeLocalizeds { get; set; } = new List<NopProductAttributeLocalized>();

    public virtual ICollection<NopProductVariantProductAttributeMapping> NopProductVariantProductAttributeMappings { get; set; } = new List<NopProductVariantProductAttributeMapping>();
}
