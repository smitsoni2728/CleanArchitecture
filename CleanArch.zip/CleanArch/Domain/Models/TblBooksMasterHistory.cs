﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBooksMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int BookId { get; set; }

    public string OldbookName { get; set; } = null!;

    public string OldbookAuthor { get; set; } = null!;

    public int OldbookEdition { get; set; }

    public decimal OldbookPrice { get; set; }

    public string OldbookLanguage { get; set; } = null!;

    public string? OldbookDescription { get; set; }

    public bool OldisActive { get; set; }

    public string NewbookName { get; set; } = null!;

    public string NewbookAuthor { get; set; } = null!;

    public int NewbookEdition { get; set; }

    public decimal NewbookPrice { get; set; }

    public string NewbookLanguage { get; set; } = null!;

    public string? NewbookDescription { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public string OldbookCode { get; set; } = null!;

    public string NewbookCode { get; set; } = null!;
}
