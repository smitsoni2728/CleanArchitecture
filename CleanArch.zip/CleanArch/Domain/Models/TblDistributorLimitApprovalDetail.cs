﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorLimitApprovalDetail
{
    public int LimitApprovalDetId { get; set; }

    public int RequestId { get; set; }

    public decimal TranAmount { get; set; }

    public int DistributorId { get; set; }

    public string RequestType { get; set; } = null!;

    public string Remark { get; set; } = null!;

    public int PaymentGatewayPgapiprocessLinkId { get; set; }

    public string ChqDdno { get; set; } = null!;

    public DateTime CashChqDddate { get; set; }

    public string BankName { get; set; } = null!;

    public string BankBranch { get; set; } = null!;

    public int BankId { get; set; }

    public bool IsApproved { get; set; }

    public bool IsRejected { get; set; }

    public int AppRejById { get; set; }

    public string AppRejRemark { get; set; } = null!;

    public DateTime AppRejDate { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public string City { get; set; } = null!;

    public string State { get; set; } = null!;
}
