﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponMaster
{
    public int CouponId { get; set; }

    public int CouponOrderDetId { get; set; }

    public int CouponDetId { get; set; }

    public int VendorId { get; set; }

    public int EventId { get; set; }

    public int CustomerId { get; set; }

    public string CouponCode { get; set; } = null!;

    public string CoponName { get; set; } = null!;

    public string CoponDetails { get; set; } = null!;

    public DateTime CoponStartDate { get; set; }

    public DateTime CoponEndDate { get; set; }

    public string Status { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
