﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductTemplate
{
    public int ProductTemplateId { get; set; }

    public string Name { get; set; } = null!;

    public string TemplatePath { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopProduct> NopProducts { get; set; } = new List<NopProduct>();
}
