﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductAttributeLocalized
{
    public int ProductAttributeLocalizedId { get; set; }

    public int ProductAttributeId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopProductAttribute ProductAttribute { get; set; } = null!;
}
