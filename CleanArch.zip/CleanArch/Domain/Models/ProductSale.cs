﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ProductSale
{
    public int SalesId { get; set; }

    public int? ProductId { get; set; }

    public string? SalesPerson { get; set; }

    public virtual Product1? Product { get; set; }
}
