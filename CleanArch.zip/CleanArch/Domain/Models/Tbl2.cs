﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tbl2
{
    public int Id { get; set; }

    public string Name1 { get; set; } = null!;

    public Guid MsreplTranVersion { get; set; }

    public string? Name12 { get; set; }
}
