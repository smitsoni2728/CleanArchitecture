﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Malay
{
    public int? EmpNo { get; set; }
}
