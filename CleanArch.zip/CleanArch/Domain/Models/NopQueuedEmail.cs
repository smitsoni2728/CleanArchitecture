﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopQueuedEmail
{
    public int QueuedEmailId { get; set; }

    public int Priority { get; set; }

    public string From { get; set; } = null!;

    public string FromName { get; set; } = null!;

    public string To { get; set; } = null!;

    public string ToName { get; set; } = null!;

    public string Cc { get; set; } = null!;

    public string Bcc { get; set; } = null!;

    public string Subject { get; set; } = null!;

    public string Body { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public int SendTries { get; set; }

    public DateTime? SentOn { get; set; }

    public int EmailAccountId { get; set; }
}
