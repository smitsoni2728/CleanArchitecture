﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAirlineMasterD1
{
    public int AirlineId { get; set; }

    public string AirlineCode { get; set; } = null!;

    public string AirlineName { get; set; } = null!;

    public string Country { get; set; } = null!;

    public bool IsDomestic { get; set; }

    public bool IsInternational { get; set; }

    public bool IsActive { get; set; }

    public int CommandId { get; set; }

    public long CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CrateIp { get; set; } = null!;

    public long UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
