﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmpHi
{
    public int EmpId { get; set; }

    public string Ename { get; set; } = null!;

    public string Title { get; set; } = null!;
}
