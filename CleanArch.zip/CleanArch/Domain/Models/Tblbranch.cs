﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tblbranch
{
    public int? IBranchId { get; set; }

    public string? CBranchCode { get; set; }

    public string? CBranchName { get; set; }
}
