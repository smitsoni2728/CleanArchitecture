﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopForumsGroup
{
    public int ForumGroupId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopForumsForum> NopForumsForums { get; set; } = new List<NopForumsForum>();
}
