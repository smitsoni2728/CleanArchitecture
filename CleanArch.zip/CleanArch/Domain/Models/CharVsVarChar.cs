﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class CharVsVarChar
{
    public string? Charname { get; set; }

    public string? Varname { get; set; }
}
