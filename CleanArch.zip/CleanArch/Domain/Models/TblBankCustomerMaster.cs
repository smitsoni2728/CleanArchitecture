﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBankCustomerMaster
{
    public int CustId { get; set; }

    public int BankId { get; set; }

    public int BranchId { get; set; }

    public string AccNo { get; set; } = null!;

    public string CustName { get; set; } = null!;

    public string Address { get; set; } = null!;

    public string City { get; set; } = null!;

    public string ContactNo { get; set; } = null!;

    public string Email { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
