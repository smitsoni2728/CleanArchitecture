﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopAcl
{
    public int Aclid { get; set; }

    public int CustomerActionId { get; set; }

    public int CustomerRoleId { get; set; }

    public bool Allow { get; set; }

    public virtual NopCustomerAction CustomerAction { get; set; } = null!;

    public virtual NopCustomerRole CustomerRole { get; set; } = null!;
}
