﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircustomerDetailHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CustomerId { get; set; }

    public int OldcustomerGroupId { get; set; }

    public string OldfirstName { get; set; } = null!;

    public string OldlastName { get; set; } = null!;

    public string Oldgender { get; set; } = null!;

    public DateTime OldbirthDate { get; set; }

    public DateTime OldanniversaryDate { get; set; }

    public string OldpassportNo { get; set; } = null!;

    public DateTime OldpassPortExpDate { get; set; }

    public int OldpassPortIssuingCountry { get; set; }

    public int OldnationalityCountry { get; set; }

    public string OldmobileNo { get; set; } = null!;

    public string OldemailId { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewfirstName { get; set; } = null!;

    public string NewlastName { get; set; } = null!;

    public string Newgender { get; set; } = null!;

    public DateTime NewbirthDate { get; set; }

    public DateTime NewanniversaryDate { get; set; }

    public string NewpassportNo { get; set; } = null!;

    public DateTime NewpassPortExpDate { get; set; }

    public int NewpassPortIssuingCountry { get; set; }

    public int NewnationalityCountry { get; set; }

    public string NewmobileNo { get; set; } = null!;

    public string NewemailId { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public int NewcustomerGroupId { get; set; }
}
