﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class StudentMark
{
    public int? StudentId { get; set; }

    public string? Name { get; set; }

    public int? Subject1 { get; set; }

    public int? Subject2 { get; set; }

    public int? Subject3 { get; set; }

    public int? Total { get; set; }

    public int? Percentage { get; set; }
}
