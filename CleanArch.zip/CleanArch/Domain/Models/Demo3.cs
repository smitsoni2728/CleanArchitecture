﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Demo3
{
    public int DepartId { get; set; }

    public string? DepartName { get; set; }

    public string? Description { get; set; }
}
