﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblBookMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int BookId { get; set; }

    public string OldbookCode { get; set; } = null!;

    public string OldbookName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewbookCode { get; set; } = null!;

    public string NewbookName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public int OldbookTypeId { get; set; }

    public int NewbookTypeId { get; set; }
}
