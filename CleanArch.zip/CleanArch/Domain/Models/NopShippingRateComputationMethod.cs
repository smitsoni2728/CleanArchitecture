﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopShippingRateComputationMethod
{
    public int ShippingRateComputationMethodId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string ConfigureTemplatePath { get; set; } = null!;

    public string ClassName { get; set; } = null!;

    public bool IsActive { get; set; }

    public int DisplayOrder { get; set; }
}
