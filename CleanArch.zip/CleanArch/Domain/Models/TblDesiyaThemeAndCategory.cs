﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaThemeAndCategory
{
    public string? VendorId { get; set; }

    public string? VendorName { get; set; }

    public string? ThemeList { get; set; }

    public string? CategoryList { get; set; }
}
