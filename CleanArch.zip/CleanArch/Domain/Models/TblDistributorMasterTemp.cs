﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistributorMasterTemp
{
    public int DistributorId { get; set; }

    public int TypeId { get; set; }

    public string Name { get; set; } = null!;

    public string DistributorCode { get; set; } = null!;

    public string CmpName { get; set; } = null!;

    public string Add1 { get; set; } = null!;

    public string Add2 { get; set; } = null!;

    public string Add3 { get; set; } = null!;

    public string City { get; set; } = null!;

    public string State { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string Pincode { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string Mobile { get; set; } = null!;

    public string Fax { get; set; } = null!;

    public string Pan { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string TranPwd { get; set; } = null!;

    public DateTime DateOfBirth { get; set; }

    public byte DistributorLevel { get; set; }

    public int Level1DistributorId { get; set; }

    public int Level2DistributorId { get; set; }

    public DateTime JoiningDate { get; set; }

    public string Padd1 { get; set; } = null!;

    public string Padd2 { get; set; } = null!;

    public string Padd3 { get; set; } = null!;

    public string Pcity { get; set; } = null!;

    public string Pstate { get; set; } = null!;

    public string Pcountry { get; set; } = null!;

    public string Ppincode { get; set; } = null!;

    public string Pphone { get; set; } = null!;

    public string Pmobile { get; set; } = null!;

    public string Pfax { get; set; } = null!;

    public bool IsCustomer { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
