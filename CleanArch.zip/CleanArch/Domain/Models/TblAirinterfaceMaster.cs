﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAirinterfaceMaster
{
    public int InterfaceId { get; set; }

    public string Description { get; set; } = null!;

    public string AuthKey { get; set; } = null!;

    public string InterfaceVersionNo { get; set; } = null!;

    public decimal DomesticSerTaxPer { get; set; }

    public decimal InternationalSerTaxPer { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdatedBy { get; set; }

    public DateTime UpdatedDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public string IpaddressEnabled { get; set; } = null!;

    public bool IsWhiteLabel { get; set; }

    public short LoginUidexpiredSec { get; set; }

    public string ApplyOnServiceTax { get; set; } = null!;

    public DateTime EffectiveServiceTaxDate { get; set; }

    public string EffectiveApplyOnServiceTax { get; set; } = null!;

    public decimal EffDomesticSerTaxPer { get; set; }

    public decimal EffInternationalSerTaxPer { get; set; }

    public bool IsActiveServiceTax { get; set; }
}
