﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCheckoutAttributeValueLocalized
{
    public int CheckoutAttributeValueLocalizedId { get; set; }

    public int CheckoutAttributeValueId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public virtual NopCheckoutAttributeValue CheckoutAttributeValue { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;
}
