﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAirlineMaster
{
    public int AirlineId { get; set; }

    public string AirlineName { get; set; } = null!;

    public string Address1 { get; set; } = null!;

    public string Address2 { get; set; } = null!;

    public string Address3 { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string State { get; set; } = null!;

    public string City { get; set; } = null!;

    public string PinCode { get; set; } = null!;

    public string AirlineCode { get; set; } = null!;

    public string AirlineUrl { get; set; } = null!;

    public string ContactName { get; set; } = null!;

    public string EmailId { get; set; } = null!;

    public string MobileNo { get; set; } = null!;

    public int AirlineTypeId { get; set; }

    public string ThumbImageName { get; set; } = null!;

    public string ImageName { get; set; } = null!;

    public bool IsActive { get; set; }

    public bool IsDisplay { get; set; }

    public bool IsDomestic { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdatedBy { get; set; }

    public DateTime UpdatedDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public string ContactNo { get; set; } = null!;
}
