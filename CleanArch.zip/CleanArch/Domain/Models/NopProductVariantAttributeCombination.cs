﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariantAttributeCombination
{
    public int ProductVariantAttributeCombinationId { get; set; }

    public int ProductVariantId { get; set; }

    public string AttributesXml { get; set; } = null!;

    public int StockQuantity { get; set; }

    public bool AllowOutOfStockOrders { get; set; }

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
