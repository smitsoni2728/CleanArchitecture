﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class _0IsActive
{
    public string StudName { get; set; } = null!;

    public bool IsActive { get; set; }
}
