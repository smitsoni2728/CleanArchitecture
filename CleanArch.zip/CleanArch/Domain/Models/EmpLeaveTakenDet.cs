﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmpLeaveTakenDet
{
    public decimal EltkLeaveid { get; set; }

    public decimal? EltkEmpid { get; set; }
}
