﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopRecurringPaymentHistory
{
    public int RecurringPaymentHistoryId { get; set; }

    public int RecurringPaymentId { get; set; }

    public int OrderId { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopRecurringPayment RecurringPayment { get; set; } = null!;
}
