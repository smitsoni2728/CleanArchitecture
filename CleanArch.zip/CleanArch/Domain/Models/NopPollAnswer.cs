﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopPollAnswer
{
    public int PollAnswerId { get; set; }

    public int PollId { get; set; }

    public string Name { get; set; } = null!;

    public int Count { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopPollVotingRecord> NopPollVotingRecords { get; set; } = new List<NopPollVotingRecord>();

    public virtual NopPoll Poll { get; set; } = null!;
}
