﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblcommandEmp
{
    public byte? Commandid { get; set; }

    public string? Commandtype { get; set; }

    public string? Commanddesc { get; set; }

    public string? Commandproc { get; set; }
}
