﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopOrder
{
    public int OrderId { get; set; }

    public Guid OrderGuid { get; set; }

    public int CustomerId { get; set; }

    public int CustomerLanguageId { get; set; }

    public int CustomerTaxDisplayTypeId { get; set; }

    public string CustomerIp { get; set; } = null!;

    public decimal OrderSubtotalInclTax { get; set; }

    public decimal OrderSubtotalExclTax { get; set; }

    public decimal OrderSubTotalDiscountInclTax { get; set; }

    public decimal OrderSubTotalDiscountExclTax { get; set; }

    public decimal OrderShippingInclTax { get; set; }

    public decimal OrderShippingExclTax { get; set; }

    public decimal PaymentMethodAdditionalFeeInclTax { get; set; }

    public decimal PaymentMethodAdditionalFeeExclTax { get; set; }

    public string TaxRates { get; set; } = null!;

    public decimal OrderTax { get; set; }

    public decimal OrderTotal { get; set; }

    public decimal RefundedAmount { get; set; }

    public decimal OrderDiscount { get; set; }

    public decimal OrderSubtotalInclTaxInCustomerCurrency { get; set; }

    public decimal OrderSubtotalExclTaxInCustomerCurrency { get; set; }

    public decimal OrderSubTotalDiscountInclTaxInCustomerCurrency { get; set; }

    public decimal OrderSubTotalDiscountExclTaxInCustomerCurrency { get; set; }

    public decimal OrderShippingInclTaxInCustomerCurrency { get; set; }

    public decimal OrderShippingExclTaxInCustomerCurrency { get; set; }

    public decimal PaymentMethodAdditionalFeeInclTaxInCustomerCurrency { get; set; }

    public decimal PaymentMethodAdditionalFeeExclTaxInCustomerCurrency { get; set; }

    public string TaxRatesInCustomerCurrency { get; set; } = null!;

    public decimal OrderTaxInCustomerCurrency { get; set; }

    public decimal OrderTotalInCustomerCurrency { get; set; }

    public decimal OrderDiscountInCustomerCurrency { get; set; }

    public string CustomerCurrencyCode { get; set; } = null!;

    public string CheckoutAttributeDescription { get; set; } = null!;

    public string CheckoutAttributesXml { get; set; } = null!;

    public decimal OrderWeight { get; set; }

    public int AffiliateId { get; set; }

    public int OrderStatusId { get; set; }

    public bool AllowStoringCreditCardNumber { get; set; }

    public string CardType { get; set; } = null!;

    public string CardName { get; set; } = null!;

    public string CardNumber { get; set; } = null!;

    public string MaskedCreditCardNumber { get; set; } = null!;

    public string CardCvv2 { get; set; } = null!;

    public string CardExpirationMonth { get; set; } = null!;

    public string CardExpirationYear { get; set; } = null!;

    public int PaymentMethodId { get; set; }

    public string PaymentMethodName { get; set; } = null!;

    public string AuthorizationTransactionId { get; set; } = null!;

    public string AuthorizationTransactionCode { get; set; } = null!;

    public string AuthorizationTransactionResult { get; set; } = null!;

    public string CaptureTransactionId { get; set; } = null!;

    public string CaptureTransactionResult { get; set; } = null!;

    public string SubscriptionTransactionId { get; set; } = null!;

    public string PurchaseOrderNumber { get; set; } = null!;

    public int PaymentStatusId { get; set; }

    public DateTime? PaidDate { get; set; }

    public string BillingFirstName { get; set; } = null!;

    public string BillingLastName { get; set; } = null!;

    public string BillingPhoneNumber { get; set; } = null!;

    public string BillingEmail { get; set; } = null!;

    public string BillingFaxNumber { get; set; } = null!;

    public string BillingCompany { get; set; } = null!;

    public string BillingAddress1 { get; set; } = null!;

    public string BillingAddress2 { get; set; } = null!;

    public string BillingCity { get; set; } = null!;

    public string BillingStateProvince { get; set; } = null!;

    public int BillingStateProvinceId { get; set; }

    public string BillingZipPostalCode { get; set; } = null!;

    public string BillingCountry { get; set; } = null!;

    public int BillingCountryId { get; set; }

    public int ShippingStatusId { get; set; }

    public string ShippingFirstName { get; set; } = null!;

    public string ShippingLastName { get; set; } = null!;

    public string ShippingPhoneNumber { get; set; } = null!;

    public string ShippingEmail { get; set; } = null!;

    public string ShippingFaxNumber { get; set; } = null!;

    public string ShippingCompany { get; set; } = null!;

    public string ShippingAddress1 { get; set; } = null!;

    public string ShippingAddress2 { get; set; } = null!;

    public string ShippingCity { get; set; } = null!;

    public string ShippingStateProvince { get; set; } = null!;

    public int ShippingStateProvinceId { get; set; }

    public string ShippingZipPostalCode { get; set; } = null!;

    public string ShippingCountry { get; set; } = null!;

    public int ShippingCountryId { get; set; }

    public string ShippingMethod { get; set; } = null!;

    public int ShippingRateComputationMethodId { get; set; }

    public DateTime? ShippedDate { get; set; }

    public string TrackingNumber { get; set; } = null!;

    public DateTime? DeliveryDate { get; set; }

    public string VatNumber { get; set; } = null!;

    public bool Deleted { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual ICollection<NopDiscountUsageHistory> NopDiscountUsageHistories { get; set; } = new List<NopDiscountUsageHistory>();

    public virtual ICollection<NopOrderNote> NopOrderNotes { get; set; } = new List<NopOrderNote>();

    public virtual ICollection<NopOrderProductVariant> NopOrderProductVariants { get; set; } = new List<NopOrderProductVariant>();
}
