﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmpDhavan
{
    public int EmpId { get; set; }

    public int EmpCode { get; set; }

    public string EmpName { get; set; } = null!;

    public bool IsActive { get; set; }

    public DateTime CreateDate { get; set; }

    public DateTime UpdateDate { get; set; }

    public int CreateBy { get; set; }

    public int UpdateBy { get; set; }
}
