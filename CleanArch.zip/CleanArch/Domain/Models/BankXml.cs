﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class BankXml
{
    public int Id { get; set; }

    public string? Bxml { get; set; }
}
