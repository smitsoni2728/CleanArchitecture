﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class AnnualLeaveInfoMaster
{
    public decimal AlimId { get; set; }

    public decimal? AlimTotallEave { get; set; }
}
