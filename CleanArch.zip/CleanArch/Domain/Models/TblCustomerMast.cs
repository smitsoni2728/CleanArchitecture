﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCustomerMast
{
    public int CustmerId { get; set; }

    public string? CustmerName { get; set; }

    public int? CustomerCode { get; set; }

    public string? Address { get; set; }

    public int? SelectedItem { get; set; }

    public decimal? TotalPrice { get; set; }
}
