﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class DscImage
{
    public int ImageId { get; set; }

    public byte[] Bits { get; set; } = null!;

    public string Mime { get; set; } = null!;

    public DateTime TimeUpdated { get; set; }

    public virtual ICollection<DscManufacturer> DscManufacturers { get; set; } = new List<DscManufacturer>();
}
