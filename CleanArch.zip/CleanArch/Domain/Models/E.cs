﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class E
{
    public int Eid { get; set; }

    public string? Ename { get; set; }

    public decimal? Esalary { get; set; }

    public string? Edesignation { get; set; }

    public string? Ecity { get; set; }
}
