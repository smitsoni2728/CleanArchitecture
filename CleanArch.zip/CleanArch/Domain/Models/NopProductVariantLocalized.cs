﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariantLocalized
{
    public int ProductVariantLocalizedId { get; set; }

    public int ProductVariantId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopProductVariant ProductVariant { get; set; } = null!;
}
