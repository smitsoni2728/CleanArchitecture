﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblApistationLinkMasterBu
{
    public int ApistationLinkId { get; set; }

    public int Apiid { get; set; }

    public int StationId { get; set; }

    public string StationAlias { get; set; } = null!;

    public string StationName { get; set; } = null!;

    public int ApicityId { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
