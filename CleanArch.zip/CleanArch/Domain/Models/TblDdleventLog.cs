﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDdleventLog
{
    public int Id { get; set; }

    public DateTime? EventTime { get; set; }

    public string? EventType { get; set; }

    public string? ServerName { get; set; }

    public string? DatabaseName { get; set; }

    public string? ObjectType { get; set; }

    public string? ObjectName { get; set; }

    public string? UserName { get; set; }

    public string? CommandText { get; set; }
}
