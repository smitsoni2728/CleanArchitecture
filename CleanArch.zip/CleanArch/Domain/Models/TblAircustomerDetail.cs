﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircustomerDetail
{
    public int CustomerId { get; set; }

    public int CustomerGroupId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public DateTime BirthDate { get; set; }

    public DateTime AnniversaryDate { get; set; }

    public string PassportNo { get; set; } = null!;

    public DateTime PassPortExpDate { get; set; }

    public int PassPortIssuingCountry { get; set; }

    public int NationalityCountry { get; set; }

    public string MobileNo { get; set; } = null!;

    public string EmailId { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
