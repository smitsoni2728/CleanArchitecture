﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommissionMaster
{
    public int CommissionId { get; set; }

    public string CommissionCode { get; set; } = null!;

    public string DistributorGroupDealIds { get; set; } = null!;

    public decimal IatapassengerFeePer { get; set; }

    public decimal IatapassengerFeeAmt { get; set; }

    public decimal IatafuelFeePer { get; set; }

    public decimal IatafuelFeeAmt { get; set; }

    public decimal IatatotalFlightAmountPer { get; set; }

    public decimal IatatotalFlightAmountAmt { get; set; }

    public decimal PlbpassengerFeePer { get; set; }

    public decimal PlbpassengerFeeAmt { get; set; }

    public decimal PlbfuelFeePer { get; set; }

    public decimal PlbfuelFeeAmt { get; set; }

    public decimal PlbtotalFlightAmountPer { get; set; }

    public decimal PlbtotalFlightAmountAmt { get; set; }

    public decimal ServiceChargeAmt { get; set; }

    public bool IsPaxServiceChargeAmt { get; set; }

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public decimal BaseFareMarkupAmt { get; set; }

    public bool IsPaxBaseFareMarkupAmt { get; set; }

    public int CommCriteriaId { get; set; }
}
