﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopOrderNote
{
    public int OrderNoteId { get; set; }

    public int OrderId { get; set; }

    public string Note { get; set; } = null!;

    public bool DisplayToCustomer { get; set; }

    public DateTime CreatedOn { get; set; }

    public virtual NopOrder Order { get; set; } = null!;
}
