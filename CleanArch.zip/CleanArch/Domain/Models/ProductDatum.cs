﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ProductDatum
{
    public int? Id { get; set; }

    public string? ProductName { get; set; }

    public string? Price { get; set; }
}
