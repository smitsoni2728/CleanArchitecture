﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopSpecificationAttributeLocalized
{
    public int SpecificationAttributeLocalizedId { get; set; }

    public int SpecificationAttributeId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;

    public virtual NopSpecificationAttribute SpecificationAttribute { get; set; } = null!;
}
