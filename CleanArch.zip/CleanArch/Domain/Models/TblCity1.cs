﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCity1
{
    public int CityId { get; set; }

    public string? CityName { get; set; }

    public int? Cid { get; set; }

    public int? Sid { get; set; }
}
