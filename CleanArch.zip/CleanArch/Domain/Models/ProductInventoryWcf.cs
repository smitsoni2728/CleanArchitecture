﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ProductInventoryWcf
{
    public int ProductInventoryId { get; set; }

    public int ProductId { get; set; }

    public decimal Quantity { get; set; }

    public virtual ProductWcf Product { get; set; } = null!;
}
