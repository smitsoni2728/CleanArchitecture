﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tbl1
{
    public decimal? Name { get; set; }

    public string Name1 { get; set; } = null!;

    public int Id { get; set; }

    public int Id11 { get; set; }

    public bool IsActive { get; set; }

    public bool IsRead { get; set; }

    public bool IsWrite { get; set; }

    public bool IsExecute { get; set; }

    public string Fname { get; set; } = null!;

    public string Check { get; set; } = null!;

    public string Check1 { get; set; } = null!;

    public string Check2 { get; set; } = null!;

    public string Check5 { get; set; } = null!;
}
