﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCheckoutAttributeValue
{
    public int CheckoutAttributeValueId { get; set; }

    public int CheckoutAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public decimal PriceAdjustment { get; set; }

    public decimal WeightAdjustment { get; set; }

    public bool IsPreSelected { get; set; }

    public int DisplayOrder { get; set; }

    public virtual NopCheckoutAttribute CheckoutAttribute { get; set; } = null!;

    public virtual ICollection<NopCheckoutAttributeValueLocalized> NopCheckoutAttributeValueLocalizeds { get; set; } = new List<NopCheckoutAttributeValueLocalized>();
}
