﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircustomerGroupMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CustomerGroupId { get; set; }

    public int OldcustomerGroupTypeId { get; set; }

    public string OldcustomerGroupName { get; set; } = null!;

    public string OldprimaryPersonMobileNo { get; set; } = null!;

    public string OldprimaryPersonEmailId { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewcustomerGroupName { get; set; } = null!;

    public string NewprimaryPersonMobileNo { get; set; } = null!;

    public string NewprimaryPersonEmailId { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public int NewcustomerGroupTypeId { get; set; }
}
