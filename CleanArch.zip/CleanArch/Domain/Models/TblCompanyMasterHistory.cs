﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCompanyMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int CompanyId { get; set; }

    public string OldcompanyCode { get; set; } = null!;

    public string OldcompanyName { get; set; } = null!;

    public string Oldaddress { get; set; } = null!;

    public string Oldphone { get; set; } = null!;

    public string OldemailId { get; set; } = null!;

    public int OldtotalEmployee { get; set; }

    public bool OldisActive { get; set; }

    public string NewcompanyCode { get; set; } = null!;

    public string NewcompanyName { get; set; } = null!;

    public string Newaddress { get; set; } = null!;

    public string Newphone { get; set; } = null!;

    public string NewemailId { get; set; } = null!;

    public int NewtotalEmployee { get; set; }

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public int OldcompanyTypeId { get; set; }

    public int NewcompanyTypeId { get; set; }
}
