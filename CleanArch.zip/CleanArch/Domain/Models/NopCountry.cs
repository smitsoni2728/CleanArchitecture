﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCountry
{
    public int CountryId { get; set; }

    public string Name { get; set; } = null!;

    public bool AllowsRegistration { get; set; }

    public bool AllowsBilling { get; set; }

    public bool AllowsShipping { get; set; }

    public string TwoLetterIsocode { get; set; } = null!;

    public string ThreeLetterIsocode { get; set; } = null!;

    public int NumericIsocode { get; set; }

    public bool SubjectToVat { get; set; }

    public bool Published { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopShippingByWeightAndCountry> NopShippingByWeightAndCountries { get; set; } = new List<NopShippingByWeightAndCountry>();

    public virtual ICollection<NopStateProvince> NopStateProvinces { get; set; } = new List<NopStateProvince>();

    public virtual ICollection<NopTaxRate> NopTaxRates { get; set; } = new List<NopTaxRate>();

    public virtual ICollection<NopPaymentMethod> PaymentMethods { get; set; } = new List<NopPaymentMethod>();

    public virtual ICollection<NopShippingMethod> ShippingMethods { get; set; } = new List<NopShippingMethod>();
}
