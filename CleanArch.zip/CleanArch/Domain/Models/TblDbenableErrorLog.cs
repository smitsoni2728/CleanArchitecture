﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDbenableErrorLog
{
    public bool IsLogEnable { get; set; }
}
