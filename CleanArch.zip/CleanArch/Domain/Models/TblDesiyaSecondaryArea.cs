﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaSecondaryArea
{
    public string? VendorId { get; set; }

    public string? VendorName { get; set; }

    public string? SecondaryAreaIds { get; set; }

    public string? SecondaryAreaName { get; set; }
}
