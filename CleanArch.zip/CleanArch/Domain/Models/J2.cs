﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class J2
{
    public int? Empno { get; set; }

    public string? Ename { get; set; }

    public Guid Rowguid { get; set; }
}
