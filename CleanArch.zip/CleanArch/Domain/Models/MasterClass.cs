namespace Domain.Models;

public class MasterClass
{
    public List<Newempmast> Newempmasts { get; set; }

    public Newdeptmast Newdeptmast { get; set; }
}