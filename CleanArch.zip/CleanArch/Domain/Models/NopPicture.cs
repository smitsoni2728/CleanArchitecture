﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopPicture
{
    public int PictureId { get; set; }

    public byte[] PictureBinary { get; set; } = null!;

    public bool IsNew { get; set; }

    public string MimeType { get; set; } = null!;

    public virtual ICollection<NopProductPicture> NopProductPictures { get; set; } = new List<NopProductPicture>();
}
