﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductSpecificationAttributeMapping
{
    public int ProductSpecificationAttributeId { get; set; }

    public int ProductId { get; set; }

    public int SpecificationAttributeOptionId { get; set; }

    public bool AllowFiltering { get; set; }

    public bool? ShowOnProductPage { get; set; }

    public int DisplayOrder { get; set; }

    public virtual NopProduct Product { get; set; } = null!;

    public virtual NopSpecificationAttributeOption SpecificationAttributeOption { get; set; } = null!;
}
