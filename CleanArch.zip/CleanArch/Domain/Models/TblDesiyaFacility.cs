﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDesiyaFacility
{
    public string? VendorId { get; set; }

    public string? AmenityId { get; set; }

    public string? AmenityType { get; set; }

    public string? Description { get; set; }
}
