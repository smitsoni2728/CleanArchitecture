﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopAddress
{
    public int AddressId { get; set; }

    public int CustomerId { get; set; }

    public bool IsBillingAddress { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string FaxNumber { get; set; } = null!;

    public string Company { get; set; } = null!;

    public string Address1 { get; set; } = null!;

    public string Address2 { get; set; } = null!;

    public string City { get; set; } = null!;

    public int StateProvinceId { get; set; }

    public string ZipPostalCode { get; set; } = null!;

    public int CountryId { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;
}
