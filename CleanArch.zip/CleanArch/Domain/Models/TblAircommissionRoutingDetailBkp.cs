﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAircommissionRoutingDetailBkp
{
    public int CommRoutingDetId { get; set; }

    public int CommissionId { get; set; }

    public string RouteStationCode { get; set; } = null!;

    public byte OrderNo { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
