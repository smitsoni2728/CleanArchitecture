﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCtm
{
    public int CustomerId { get; set; }

    public int VendorId { get; set; }

    public string CustomerName { get; set; } = null!;
}
