﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class New1
{
    public string? Sss { get; set; }
}
