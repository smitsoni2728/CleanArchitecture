﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tbldepartment
{
    public string? Deptid { get; set; }

    public string? Departmentname { get; set; }

    public string? Status { get; set; }
}
