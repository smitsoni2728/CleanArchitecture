﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopPaymentMethod
{
    public int PaymentMethodId { get; set; }

    public string Name { get; set; } = null!;

    public string VisibleName { get; set; } = null!;

    public string Description { get; set; } = null!;

    public string ConfigureTemplatePath { get; set; } = null!;

    public string UserTemplatePath { get; set; } = null!;

    public string ClassName { get; set; } = null!;

    public string SystemKeyword { get; set; } = null!;

    public bool IsActive { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopCountry> Countries { get; set; } = new List<NopCountry>();
}
