﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAirdownlineCommissionMasterBkp
{
    public int DownlineCommissionId { get; set; }

    public int FromDistId { get; set; }

    public int ToDistId { get; set; }

    public int CommissionId { get; set; }

    public decimal IatapassengerFeePer { get; set; }

    public decimal IatapassengerFeeAmt { get; set; }

    public decimal IatafuelFeePer { get; set; }

    public decimal IatafuelFeeAmt { get; set; }

    public decimal IatatotalFlightAmountPer { get; set; }

    public decimal IatatotalFlightAmountAmt { get; set; }

    public decimal PlbpassengerFeePer { get; set; }

    public decimal PlbpassengerFeeAmt { get; set; }

    public decimal PlbfuelFeePer { get; set; }

    public decimal PlbfuelFeeAmt { get; set; }

    public decimal PlbtotalFlightAmountPer { get; set; }

    public decimal PlbtotalFlightAmountAmt { get; set; }

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
