﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblClassMaster
{
    public int ClassId { get; set; }

    public string ClassCode { get; set; } = null!;

    public string ClassDesc { get; set; } = null!;

    public string Remark { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public string CreateIp { get; set; } = null!;

    public DateTime CreateDate { get; set; }

    public int CreateBy { get; set; }

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
