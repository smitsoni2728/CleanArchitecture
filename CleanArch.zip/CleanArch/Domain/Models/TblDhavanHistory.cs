﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDhavanHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int UserTypeId { get; set; }

    public string OldEmpCode { get; set; } = null!;

    public string OldEmpName { get; set; } = null!;

    public string NewEmpCode { get; set; } = null!;

    public string NewEmpName { get; set; } = null!;

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;

    public int? UserId { get; set; }
}
