﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistAdminMenuInVisibleByDistTypeHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int Id { get; set; }

    public byte OldtypeDetId { get; set; }

    public int OldmenuId { get; set; }

    public byte NewtypeDetId { get; set; }

    public int NewmenuId { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
