﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopMeasureWeight
{
    public int MeasureWeightId { get; set; }

    public string Name { get; set; } = null!;

    public string SystemKeyword { get; set; } = null!;

    public decimal Ratio { get; set; }

    public int DisplayOrder { get; set; }
}
