﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductReviewHelpfulness
{
    public int ProductReviewHelpfulnessId { get; set; }

    public int ProductReviewId { get; set; }

    public int CustomerId { get; set; }

    public bool WasHelpful { get; set; }

    public virtual NopProductReview ProductReview { get; set; } = null!;
}
