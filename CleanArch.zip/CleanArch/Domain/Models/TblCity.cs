﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCity
{
    public int? CityId { get; set; }

    public string? CityName { get; set; }

    public string? CityType { get; set; }
}
