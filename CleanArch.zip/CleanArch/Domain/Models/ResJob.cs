﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResJob
{
    public string? Datasource { get; set; }

    public int? IjobId { get; set; }

    public string? CjobName { get; set; }

    public string? CcompanyName { get; set; }
}
