﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDistAdminMenuMaster
{
    public int MenuId { get; set; }

    public int ParentMenuId { get; set; }

    public string MenuCaption { get; set; } = null!;

    public string MenuControlName { get; set; } = null!;

    public byte MenuLevel { get; set; }

    public byte OrderNo { get; set; }

    public string LogoUrl { get; set; } = null!;

    public bool IsNewWindow { get; set; }

    public bool IsActive { get; set; }

    public byte SubMenuNo { get; set; }

    public byte TotSubMenu { get; set; }

    public string MenuKey { get; set; } = null!;

    public byte CommandId { get; set; }

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;

    public string MenuToolTip { get; set; } = null!;
}
