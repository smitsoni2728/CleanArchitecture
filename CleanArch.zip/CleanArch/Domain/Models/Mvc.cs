﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Mvc
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Address { get; set; }

    public decimal? MobileNo { get; set; }

    public string? StateName { get; set; }

    public string? CityName { get; set; }
}
