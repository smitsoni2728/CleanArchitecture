﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Patientmaster
{
    public string Opdno { get; set; } = null!;

    public string? Name { get; set; }

    public decimal? Age { get; set; }

    public string? Sex { get; set; }

    public string? Camp { get; set; }

    public string? Mobileno { get; set; }

    public string? Place { get; set; }

    public DateTime? Registerdate { get; set; }

    public TimeSpan? Registertime { get; set; }
}
