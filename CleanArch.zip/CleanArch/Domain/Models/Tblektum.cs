﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tblektum
{
    public int? Id { get; set; }
}
