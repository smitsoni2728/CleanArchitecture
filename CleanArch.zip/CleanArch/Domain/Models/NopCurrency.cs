﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCurrency
{
    public int CurrencyId { get; set; }

    public string Name { get; set; } = null!;

    public string CurrencyCode { get; set; } = null!;

    public string? DisplayLocale { get; set; }

    public decimal Rate { get; set; }

    public string CustomFormatting { get; set; } = null!;

    public bool Published { get; set; }

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }
}
