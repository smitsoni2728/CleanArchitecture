﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCountry
{
    public int Cid { get; set; }

    public string? Cname { get; set; }
}
