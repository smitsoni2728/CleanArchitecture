﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCardLedger
{
    public int CardLedgerId { get; set; }

    public DateTime TranDate { get; set; }

    public int RpgenerationId { get; set; }

    public int CardId { get; set; }

    public int OrderId { get; set; }

    public decimal RewardPointsRatePer { get; set; }

    public decimal RewardPointsRateAmount { get; set; }

    public decimal RewardPointsRateQty { get; set; }

    public decimal RewardPoints { get; set; }

    public short CreditDebit { get; set; }

    public string Remark { get; set; } = null!;

    public string Remark1 { get; set; } = null!;

    public int CreateBy { get; set; }

    public DateTime CreateDate { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
