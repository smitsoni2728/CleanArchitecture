﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class LogTable
{
    public DateTime Time { get; set; }

    public string Logger { get; set; } = null!;

    public string Level { get; set; } = null!;

    public string Thread { get; set; } = null!;

    public string Message { get; set; } = null!;
}
