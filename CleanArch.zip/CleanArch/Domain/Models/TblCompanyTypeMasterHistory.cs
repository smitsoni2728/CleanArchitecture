﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCompanyTypeMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int? CompanyTypeId { get; set; }

    public string OldcompayTypeCode { get; set; } = null!;

    public string OldcompanytypeName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewcompayTypeCode { get; set; } = null!;

    public string NewcompanytypeName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
