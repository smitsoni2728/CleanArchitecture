﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAirlineTypeMaster
{
    public int AirlineTypeId { get; set; }

    public string AirlineTypeCode { get; set; } = null!;

    public string AirlineTypeName { get; set; } = null!;

    public byte CommandId { get; set; }

    public bool IsActive { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
