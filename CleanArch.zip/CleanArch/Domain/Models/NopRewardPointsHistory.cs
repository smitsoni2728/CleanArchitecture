﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopRewardPointsHistory
{
    public int RewardPointsHistoryId { get; set; }

    public int CustomerId { get; set; }

    public int OrderId { get; set; }

    public int Points { get; set; }

    public int PointsBalance { get; set; }

    public decimal UsedAmount { get; set; }

    public decimal UsedAmountInCustomerCurrency { get; set; }

    public string CustomerCurrencyCode { get; set; } = null!;

    public string Message { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;
}
