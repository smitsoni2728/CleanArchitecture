﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class HistoryTable
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
