﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class EmpLog2
{
    public int LogId { get; set; }

    public int EmpId { get; set; }

    public string Operation { get; set; } = null!;

    public DateTime UpdatedDate { get; set; }
}
