﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopMessageTemplate
{
    public int MessageTemplateId { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<NopMessageTemplateLocalized> NopMessageTemplateLocalizeds { get; set; } = new List<NopMessageTemplateLocalized>();
}
