﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopLog
{
    public int LogId { get; set; }

    public int LogTypeId { get; set; }

    public int Severity { get; set; }

    public string Message { get; set; } = null!;

    public string Exception { get; set; } = null!;

    public string Ipaddress { get; set; } = null!;

    public int CustomerId { get; set; }

    public string PageUrl { get; set; } = null!;

    public string ReferrerUrl { get; set; } = null!;

    public DateTime CreatedOn { get; set; }
}
