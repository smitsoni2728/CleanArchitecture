﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class LeaveApprovalMaster
{
    public decimal LamsId { get; set; }

    public string? LamsApprovename { get; set; }

    public string? LamsEmail { get; set; }
}
