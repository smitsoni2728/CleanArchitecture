﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopSpecificationAttribute
{
    public int SpecificationAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopSpecificationAttributeLocalized> NopSpecificationAttributeLocalizeds { get; set; } = new List<NopSpecificationAttributeLocalized>();

    public virtual ICollection<NopSpecificationAttributeOption> NopSpecificationAttributeOptions { get; set; } = new List<NopSpecificationAttributeOption>();
}
