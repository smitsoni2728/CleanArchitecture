﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopManufacturer
{
    public int ManufacturerId { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public int TemplateId { get; set; }

    public string MetaKeywords { get; set; } = null!;

    public string MetaDescription { get; set; } = null!;

    public string MetaTitle { get; set; } = null!;

    public string Sename { get; set; } = null!;

    public int PictureId { get; set; }

    public int PageSize { get; set; }

    public string PriceRanges { get; set; } = null!;

    public bool Published { get; set; }

    public bool Deleted { get; set; }

    public int DisplayOrder { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual ICollection<NopManufacturerLocalized> NopManufacturerLocalizeds { get; set; } = new List<NopManufacturerLocalized>();

    public virtual ICollection<NopProductManufacturerMapping> NopProductManufacturerMappings { get; set; } = new List<NopProductManufacturerMapping>();

    public virtual NopManufacturerTemplate Template { get; set; } = null!;
}
