﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblDepartmentMaster1
{
    public int DepartmentId { get; set; }

    public string DepartmentCode { get; set; } = null!;

    public string DepartmentName { get; set; } = null!;
}
