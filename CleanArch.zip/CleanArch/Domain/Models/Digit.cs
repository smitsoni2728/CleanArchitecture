﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Digit
{
    public int? EmpNo { get; set; }
}
