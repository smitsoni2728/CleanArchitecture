﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCountryMaster
{
    public int CountryId { get; set; }

    public string Countrycode { get; set; } = null!;

    public string Countryname { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreateDateTime { get; set; }

    public string CreateIp { get; set; } = null!;

    public int UpdatedBy { get; set; }

    public DateTime UpdateDateTime { get; set; }

    public string UpDateIp { get; set; } = null!;
}
