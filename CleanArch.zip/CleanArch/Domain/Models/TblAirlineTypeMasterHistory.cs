﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblAirlineTypeMasterHistory
{
    public int HistoryId { get; set; }

    public byte CommandId { get; set; }

    public int AirlineTypeId { get; set; }

    public string OldairlineTypeCode { get; set; } = null!;

    public string OldairlineTypeName { get; set; } = null!;

    public bool OldisActive { get; set; }

    public string NewairlineTypeCode { get; set; } = null!;

    public string NewairlineTypeName { get; set; } = null!;

    public bool NewisActive { get; set; }

    public int HistoryBy { get; set; }

    public DateTime HistoryDate { get; set; }

    public string HistoryIp { get; set; } = null!;
}
