﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductVariantAttributeValue
{
    public int ProductVariantAttributeValueId { get; set; }

    public int ProductVariantAttributeId { get; set; }

    public string Name { get; set; } = null!;

    public decimal PriceAdjustment { get; set; }

    public decimal WeightAdjustment { get; set; }

    public bool IsPreSelected { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopProductVariantAttributeValueLocalized> NopProductVariantAttributeValueLocalizeds { get; set; } = new List<NopProductVariantAttributeValueLocalized>();

    public virtual NopProductVariantProductAttributeMapping ProductVariantAttribute { get; set; } = null!;
}
