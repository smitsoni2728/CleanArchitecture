﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopReturnRequest
{
    public int ReturnRequestId { get; set; }

    public int OrderProductVariantId { get; set; }

    public int Quantity { get; set; }

    public int CustomerId { get; set; }

    public string ReasonForReturn { get; set; } = null!;

    public string RequestedAction { get; set; } = null!;

    public string CustomerComments { get; set; } = null!;

    public string StaffNotes { get; set; } = null!;

    public int ReturnStatusId { get; set; }

    public DateTime CreatedOn { get; set; }

    public DateTime UpdatedOn { get; set; }

    public virtual NopCustomer Customer { get; set; } = null!;

    public virtual NopOrderProductVariant OrderProductVariant { get; set; } = null!;
}
