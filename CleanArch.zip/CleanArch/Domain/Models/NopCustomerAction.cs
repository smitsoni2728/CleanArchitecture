﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCustomerAction
{
    public int CustomerActionId { get; set; }

    public string Name { get; set; } = null!;

    public string SystemKeyword { get; set; } = null!;

    public string Comment { get; set; } = null!;

    public int DisplayOrder { get; set; }

    public virtual ICollection<NopAcl> NopAcls { get; set; } = new List<NopAcl>();
}
