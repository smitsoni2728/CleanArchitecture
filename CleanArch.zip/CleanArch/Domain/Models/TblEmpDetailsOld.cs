﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblEmpDetailsOld
{
    public int IntEmpDetId { get; set; }

    public int IntEmpId { get; set; }

    public string StrLoc { get; set; } = null!;

    public int IntSrNo { get; set; }

    public Guid MsreplTranVersion { get; set; }

    public Guid Rowguid { get; set; }
}
