﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class ResPlacement
{
    public int? IplacementId { get; set; }

    public string? Cplace { get; set; }

    public int? IjobId { get; set; }
}
