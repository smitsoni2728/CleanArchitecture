﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopProductTag
{
    public int ProductTagId { get; set; }

    public string Name { get; set; } = null!;

    public int ProductCount { get; set; }

    public virtual ICollection<NopProduct> Products { get; set; } = new List<NopProduct>();
}
