﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopRelatedProduct
{
    public int RelatedProductId { get; set; }

    public int ProductId1 { get; set; }

    public int ProductId2 { get; set; }

    public int DisplayOrder { get; set; }

    public virtual NopProduct ProductId1Navigation { get; set; } = null!;
}
