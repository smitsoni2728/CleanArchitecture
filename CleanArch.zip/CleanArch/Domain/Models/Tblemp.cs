﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Tblemp
{
    public string? Empid { get; set; }

    public string? Deptid { get; set; }

    public string? Empname { get; set; }

    public string? Gender { get; set; }

    public string? Mobileno { get; set; }

    public string? Dob { get; set; }

    public string? Active { get; set; }
}
