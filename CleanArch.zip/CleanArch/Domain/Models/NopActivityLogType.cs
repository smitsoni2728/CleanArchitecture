﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopActivityLogType
{
    public int ActivityLogTypeId { get; set; }

    public string SystemKeyword { get; set; } = null!;

    public string Name { get; set; } = null!;

    public bool Enabled { get; set; }

    public virtual ICollection<NopActivityLog> NopActivityLogs { get; set; } = new List<NopActivityLog>();
}
