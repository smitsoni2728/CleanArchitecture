﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class TblCouponDetail
{
    public int CouponDetId { get; set; }

    public string CouponName { get; set; } = null!;

    public string CouponDetail { get; set; } = null!;

    public decimal CouponAmount { get; set; }

    public string CouponStartDate { get; set; } = null!;

    public string CouponEndDate { get; set; } = null!;

    public bool IsActive { get; set; }

    public byte CommandId { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedIp { get; set; } = null!;

    public int UpdateBy { get; set; }

    public DateTime UpdateDate { get; set; }

    public string UpdateIp { get; set; } = null!;
}
