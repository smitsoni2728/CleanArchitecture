﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class Jayesh
{
    public int? A { get; set; }
}
