﻿using System;
using System.Collections.Generic;

namespace Domain.Models;

public partial class NopCheckoutAttributeLocalized
{
    public int CheckoutAttributeLocalizedId { get; set; }

    public int CheckoutAttributeId { get; set; }

    public int LanguageId { get; set; }

    public string Name { get; set; } = null!;

    public string TextPrompt { get; set; } = null!;

    public virtual NopCheckoutAttribute CheckoutAttribute { get; set; } = null!;

    public virtual NopLanguage Language { get; set; } = null!;
}
